import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Request interceptor for JWT
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('nexus_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => Promise.reject(error));

// Dashboard
export const fetchDashboardStats = async () => {
  const res = await api.get('/dashboard/stats');
  return res.data;
};

// Papers & Rabin-Karp
export const fetchPapers = async () => {
  const res = await api.get('/papers');
  return res.data;
};

export const searchPapersRabinKarp = async (query) => {
  const res = await api.post('/papers/search', { query });
  return res.data;
};

export const createPaper = async (paper) => {
  const res = await api.post('/papers', paper);
  return res.data;
};

export const deletePaper = async (id) => {
  const res = await api.delete(`/papers/${id}`);
  return res.data;
};

// Tasks & Graph
export const fetchTasks = async () => {
  const res = await api.get('/tasks');
  return res.data;
};

export const createTask = async (task) => {
  const res = await api.post('/tasks', task);
  return res.data;
};

export const updateTask = async (id, task) => {
  const res = await api.put(`/tasks/${id}`, task);
  return res.data;
};

export const updateTaskPosition = async (id, x, y) => {
  const res = await api.patch(`/tasks/${id}/position`, { x, y });
  return res.data;
};

export const deleteTask = async (id) => {
  const res = await api.delete(`/tasks/${id}`);
  return res.data;
};

// Dependencies
export const fetchDependencies = async () => {
  const res = await api.get('/dependencies');
  return res.data;
};

export const addDependency = async (sourceTaskId, targetTaskId, dependencyType = 'HARD', label = 'Precedes') => {
  const res = await api.post('/dependencies', { sourceTaskId, targetTaskId, dependencyType, label });
  return res.data;
};

export const deleteDependency = async (id) => {
  const res = await api.delete(`/dependencies/${id}`);
  return res.data;
};

export const toggleDeadlockScenario = async () => {
  const res = await api.post('/dependencies/toggle-deadlock');
  return res.data;
};

// Algorithms
export const runBfsAlgorithm = async (startTaskId) => {
  const res = await api.post('/algorithms/bfs', { startTaskId });
  return res.data;
};

export const runDfsAlgorithm = async (startTaskId) => {
  const res = await api.post('/algorithms/dfs', { startTaskId });
  return res.data;
};

export const runTopologicalSort = async () => {
  const res = await api.post('/algorithms/topological-sort');
  return res.data;
};

export const runTaskDispatcher = async (workerCount = 3) => {
  const res = await api.post('/algorithms/dispatch', { workerCount });
  return res.data;
};

export const fetchDiagnostics = async () => {
  const res = await api.get('/algorithms/diagnostics');
  return res.data;
};

// Seed
export const seedSampleData = async () => {
  const res = await api.post('/seed');
  return res.data;
};

// Auth
export const loginUser = async (username, password) => {
  const res = await api.post('/auth/login', { username, password });
  if (res.data?.token) {
    localStorage.setItem('nexus_token', res.data.token);
    localStorage.setItem('nexus_user', JSON.stringify(res.data));
  }
  return res.data;
};

export const registerUser = async (data) => {
  const res = await api.post('/auth/register', data);
  if (res.data?.token) {
    localStorage.setItem('nexus_token', res.data.token);
    localStorage.setItem('nexus_user', JSON.stringify(res.data));
  }
  return res.data;
};

export const logoutUser = () => {
  localStorage.removeItem('nexus_token');
  localStorage.removeItem('nexus_user');
};

export default api;
