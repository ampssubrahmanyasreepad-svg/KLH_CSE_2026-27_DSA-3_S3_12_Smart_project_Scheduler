import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import DashboardView from './components/DashboardView';
import ResearchPapersView from './components/ResearchPapersView';
import DagVisualizerView from './components/DagVisualizerView';
import AlgorithmicEngineView from './components/AlgorithmicEngineView';
import AlgorithmLabView from './components/AlgorithmLabView';
import NewTaskModal from './components/NewTaskModal';
import NewPaperModal from './components/NewPaperModal';

import { 
  fetchDashboardStats, 
  fetchTasks, 
  fetchDependencies, 
  fetchPapers, 
  runTopologicalSort, 
  toggleDeadlockScenario, 
  seedSampleData 
} from './api/client';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [dependencies, setDependencies] = useState([]);
  const [papers, setPapers] = useState([]);
  const [topologicalResult, setTopologicalResult] = useState(null);
  const [deadlockActive, setDeadlockActive] = useState(false);
  const [serverConnected, setServerConnected] = useState(false);
  const [loadingAction, setLoadingAction] = useState(false);

  // Modals state
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isPaperModalOpen, setIsPaperModalOpen] = useState(false);
  const [prefillPaper, setPrefillPaper] = useState(null);

  // Refresh all state
  const loadSystemData = async () => {
    try {
      const [sData, tData, dData, pData, topoData] = await Promise.all([
        fetchDashboardStats(),
        fetchTasks(),
        fetchDependencies(),
        fetchPapers(),
        runTopologicalSort()
      ]);

      setStats(sData);
      setTasks(tData);
      setDependencies(dData);
      setPapers(pData);
      setTopologicalResult(topoData);
      setDeadlockActive(topoData.deadlockDetected || false);
      setServerConnected(true);
    } catch (err) {
      console.warn('Backend connecting or not ready yet:', err.message);
      setServerConnected(false);
    }
  };

  useEffect(() => {
    loadSystemData();
    const interval = setInterval(loadSystemData, 4000);
    return () => clearInterval(interval);
  }, []);

  // Deadlock toggle
  const handleToggleDeadlock = async () => {
    try {
      setLoadingAction(true);
      const res = await toggleDeadlockScenario();
      setDeadlockActive(res.deadlockActive);
      await loadSystemData();
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAction(false);
    }
  };

  // Seed data
  const handleSeedData = async () => {
    try {
      setLoadingAction(true);
      await seedSampleData();
      await loadSystemData();
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAction(false);
    }
  };

  // Modal handlers
  const handleCreateTaskFromPaper = (paper) => {
    setPrefillPaper(paper);
    setIsTaskModalOpen(true);
  };

  const handleOpenAddTask = () => {
    setPrefillPaper(null);
    setIsTaskModalOpen(true);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        deadlockActive={deadlockActive}
        onToggleDeadlock={handleToggleDeadlock}
        onSeedData={handleSeedData}
        loadingAction={loadingAction}
        serverConnected={serverConnected}
      />

      {/* Main View Area */}
      <main style={{ flex: 1 }}>
        {activeTab === 'dashboard' && (
          <DashboardView
            stats={stats}
            tasks={tasks}
            papers={papers}
            deadlockActive={deadlockActive}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'papers' && (
          <ResearchPapersView
            papers={papers}
            onAddPaperClick={() => setIsPaperModalOpen(true)}
            onCreateTaskFromPaper={handleCreateTaskFromPaper}
          />
        )}

        {activeTab === 'dag' && (
          <DagVisualizerView
            tasks={tasks}
            dependencies={dependencies}
            deadlockActive={deadlockActive}
            onToggleDeadlock={handleToggleDeadlock}
            onAddTaskClick={handleOpenAddTask}
            onRefreshData={loadSystemData}
            topologicalResult={topologicalResult}
          />
        )}

        {activeTab === 'algorithms' && (
          <AlgorithmicEngineView
            tasks={tasks}
            dependencies={dependencies}
            deadlockActive={deadlockActive}
            onToggleDeadlock={handleToggleDeadlock}
          />
        )}

        {activeTab === 'lab' && (
          <AlgorithmLabView
            stats={stats}
          />
        )}
      </main>

      {/* Modals */}
      <NewTaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onTaskCreated={loadSystemData}
        papers={papers}
        prefillPaper={prefillPaper}
      />

      <NewPaperModal
        isOpen={isPaperModalOpen}
        onClose={() => setIsPaperModalOpen(false)}
        onPaperCreated={loadSystemData}
      />
    </div>
  );
}
