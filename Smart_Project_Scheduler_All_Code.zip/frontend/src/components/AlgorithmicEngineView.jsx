import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  RotateCcw, 
  Cpu, 
  GitFork, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  ArrowRight, 
  Sliders,
  ChevronRight
} from 'lucide-react';
import { 
  runTopologicalSort, 
  runBfsAlgorithm, 
  runDfsAlgorithm, 
  runTaskDispatcher 
} from '../api/client';
import confetti from 'canvas-confetti';

export default function AlgorithmicEngineView({ 
  tasks, 
  dependencies, 
  deadlockActive, 
  onToggleDeadlock 
}) {
  const [activeEngineTab, setActiveEngineTab] = useState('topological'); // topological, bfs, dfs, dispatcher
  const [loading, setLoading] = useState(false);

  // Topological Sort State
  const [topoResult, setTopoResult] = useState(null);
  const [topoStepIdx, setTopoStepIdx] = useState(0);

  // BFS State
  const [bfsResult, setBfsResult] = useState(null);
  const [bfsStepIdx, setBfsStepIdx] = useState(0);
  const [bfsPlaying, setBfsPlaying] = useState(false);
  const [bfsSpeed, setBfsSpeed] = useState(1000); // ms per step

  // DFS State
  const [dfsResult, setDfsResult] = useState(null);
  const [dfsStepIdx, setDfsStepIdx] = useState(0);
  const [dfsPlaying, setDfsPlaying] = useState(false);

  // Dispatcher State
  const [dispatchResult, setDispatchResult] = useState(null);
  const [workerCount, setWorkerCount] = useState(3);

  // Initial load
  useEffect(() => {
    fetchTopologicalData();
  }, [dependencies, tasks, deadlockActive]);

  const fetchTopologicalData = async () => {
    try {
      setLoading(true);
      const res = await runTopologicalSort();
      setTopoResult(res);
      setTopoStepIdx(res.steps ? res.steps.length - 1 : 0);
      if (!res.hasCycle && res.steps && res.steps.length > 0) {
        // Trigger celebratory confetti if clean valid DAG pipeline resolved
        try { confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } }); } catch (e) {}
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchBfsData = async () => {
    try {
      setLoading(true);
      const res = await runBfsAlgorithm(tasks[0]?.id);
      setBfsResult(res);
      setBfsStepIdx(0);
      setBfsPlaying(false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchDfsData = async () => {
    try {
      setLoading(true);
      const res = await runDfsAlgorithm(tasks[0]?.id);
      setDfsResult(res);
      setDfsStepIdx(0);
      setDfsPlaying(false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchDispatcherData = async () => {
    try {
      setLoading(true);
      const res = await runTaskDispatcher(workerCount);
      setDispatchResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // BFS auto-playback interval
  useEffect(() => {
    let timer = null;
    if (bfsPlaying && bfsResult && bfsResult.steps) {
      timer = setInterval(() => {
        setBfsStepIdx(prev => {
          if (prev < bfsResult.steps.length - 1) {
            return prev + 1;
          } else {
            setBfsPlaying(false);
            return prev;
          }
        });
      }, bfsSpeed);
    }
    return () => clearInterval(timer);
  }, [bfsPlaying, bfsResult, bfsSpeed]);

  // DFS auto-playback interval
  useEffect(() => {
    let timer = null;
    if (dfsPlaying && dfsResult && dfsResult.steps) {
      timer = setInterval(() => {
        setDfsStepIdx(prev => {
          if (prev < dfsResult.steps.length - 1) {
            return prev + 1;
          } else {
            setDfsPlaying(false);
            return prev;
          }
        });
      }, 1200);
    }
    return () => clearInterval(timer);
  }, [dfsPlaying, dfsResult]);

  return (
    <div style={{ padding: '24px 20px', maxWidth: 1400, margin: '0 auto' }}>
      {/* Sub-navigation tabs for the engine */}
      <div className="glass-panel" style={{
        padding: '8px 12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 12,
        marginBottom: 20
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => { setActiveEngineTab('topological'); fetchTopologicalData(); }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.86rem',
              fontWeight: 600,
              backgroundColor: activeEngineTab === 'topological' ? 'rgba(56, 189, 248, 0.15)' : 'transparent',
              color: activeEngineTab === 'topological' ? '#38BDF8' : 'var(--text-secondary)',
              border: activeEngineTab === 'topological' ? '1px solid rgba(56, 189, 248, 0.4)' : '1px solid transparent',
              cursor: 'pointer'
            }}
          >
            <GitFork size={16} />
            <span>Kahn's Topological Sort & Deadlock</span>
          </button>

          <button
            onClick={() => { setActiveEngineTab('bfs'); fetchBfsData(); }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.86rem',
              fontWeight: 600,
              backgroundColor: activeEngineTab === 'bfs' ? 'rgba(139, 92, 246, 0.15)' : 'transparent',
              color: activeEngineTab === 'bfs' ? '#A78BFA' : 'var(--text-secondary)',
              border: activeEngineTab === 'bfs' ? '1px solid rgba(139, 92, 246, 0.4)' : '1px solid transparent',
              cursor: 'pointer'
            }}
          >
            <Cpu size={16} />
            <span>BFS Level-Order Playback</span>
          </button>

          <button
            onClick={() => { setActiveEngineTab('dfs'); fetchDfsData(); }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.86rem',
              fontWeight: 600,
              backgroundColor: activeEngineTab === 'dfs' ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
              color: activeEngineTab === 'dfs' ? '#34D399' : 'var(--text-secondary)',
              border: activeEngineTab === 'dfs' ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid transparent',
              cursor: 'pointer'
            }}
          >
            <Sliders size={16} />
            <span>DFS Stack & Edge Tracer</span>
          </button>

          <button
            onClick={() => { setActiveEngineTab('dispatcher'); fetchDispatcherData(); }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.86rem',
              fontWeight: 600,
              backgroundColor: activeEngineTab === 'dispatcher' ? 'rgba(245, 158, 11, 0.15)' : 'transparent',
              color: activeEngineTab === 'dispatcher' ? '#FBBF24' : 'var(--text-secondary)',
              border: activeEngineTab === 'dispatcher' ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid transparent',
              cursor: 'pointer'
            }}
          >
            <Layers size={16} />
            <span>Min-Heap Priority Dispatcher</span>
          </button>
        </div>

        {/* Deadlock Injection Quick Switch */}
        <button
          onClick={onToggleDeadlock}
          className={deadlockActive ? 'btn-danger' : 'btn-secondary'}
          style={{ fontSize: '0.78rem' }}
        >
          <AlertTriangle size={14} color={deadlockActive ? '#FDA4AF' : '#F59E0B'} />
          <span>{deadlockActive ? 'Deadlock Injected (A⇄B)' : 'Inject Deadlock (A⇄B)'}</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. TOPOLOGICAL SORT / KAHN'S ALGORITHM TAB */}
      {/* ========================================================================= */}
      {activeEngineTab === 'topological' && topoResult && (
        <div>
          {/* Status Diagnostic Card */}
          <div className="glass-panel" style={{
            padding: 20,
            marginBottom: 20,
            borderColor: topoResult.deadlockDetected ? '#F43F5E' : 'rgba(16, 185, 129, 0.4)',
            backgroundColor: topoResult.deadlockDetected ? 'rgba(244, 63, 94, 0.12)' : 'rgba(16, 185, 129, 0.08)'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{
                  width: 44,
                  height: 44,
                  borderRadius: 10,
                  backgroundColor: topoResult.deadlockDetected ? 'rgba(244, 63, 94, 0.25)' : 'rgba(16, 185, 129, 0.25)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  {topoResult.deadlockDetected ? (
                    <AlertTriangle size={24} color="#FB7185" />
                  ) : (
                    <CheckCircle2 size={24} color="#34D399" />
                  )}
                </div>
                <div>
                  <h3 style={{
                    fontSize: '1.15rem',
                    fontWeight: 700,
                    color: topoResult.deadlockDetected ? '#FDA4AF' : '#34D399'
                  }}>
                    {topoResult.deadlockDetected ? 'Circular Dependency Deadlock Flagged' : 'Deterministic Linear Execution Pipeline'}
                  </h3>
                  <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: 2 }}>
                    {topoResult.diagnosticMessage}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 12, fontSize: '0.78rem' }}>
                <div style={{ padding: '6px 12px', borderRadius: 6, backgroundColor: 'rgba(0,0,0,0.3)' }}>
                  <span>Time Complexity: <strong className="font-mono" style={{ color: '#38BDF8' }}>O(V + E)</strong></span>
                </div>
                <div style={{ padding: '6px 12px', borderRadius: 6, backgroundColor: 'rgba(0,0,0,0.3)' }}>
                  <span>Execution: <strong className="font-mono" style={{ color: '#A78BFA' }}>{topoResult.executionTimeMicros} &mu;s</strong></span>
                </div>
              </div>
            </div>

            {/* If deadlock, show cycle edges list */}
            {topoResult.deadlockDetected && topoResult.cycleEdgeDescriptions && (
              <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid rgba(244, 63, 94, 0.3)' }}>
                <span style={{ fontSize: '0.78rem', color: '#FDA4AF', fontWeight: 600 }}>
                  Participating Cycle Paths:
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
                  {topoResult.cycleEdgeDescriptions.map((desc, i) => (
                    <span key={i} className="font-mono badge badge-rose" style={{ fontSize: '0.72rem' }}>
                      {desc}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Resolved Pipeline Order Timeline */}
          {!topoResult.deadlockDetected && topoResult.executionPipeline && (
            <div className="glass-panel" style={{ padding: 20, marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <h4 style={{ fontSize: '0.92rem', fontWeight: 600, color: '#F8FAFC' }}>
                  Topologically Resolved Execution Sequence ({topoResult.executionPipeline.length} Tasks)
                </h4>
                <span className="badge badge-cyan" style={{ fontSize: '0.68rem' }}>
                  Zero Dependency Inversion
                </span>
              </div>

              <div style={{
                display: 'flex',
                alignItems: 'center',
                overflowX: 'auto',
                paddingBottom: 10,
                gap: 12
              }}>
                {topoResult.executionPipeline.map((task, idx) => (
                  <React.Fragment key={task.id}>
                    <div className="glass-card" style={{
                      minWidth: 170,
                      padding: '12px 14px',
                      borderRadius: 10,
                      borderLeft: `4px solid ${task.colorTag || '#38BDF8'}`,
                      flexShrink: 0
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span className="font-mono" style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                          #{idx + 1}
                        </span>
                        <span className="font-mono" style={{ fontSize: '0.78rem', fontWeight: 700, color: '#38BDF8' }}>
                          {task.taskKey}
                        </span>
                      </div>
                      <h5 style={{ fontSize: '0.82rem', fontWeight: 600, color: '#F8FAFC', marginTop: 4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {task.title}
                      </h5>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                        <span>{task.estimatedDurationHours}h</span>
                        <span className={`badge ${
                          task.priority === 'CRITICAL' ? 'badge-rose' :
                          task.priority === 'HIGH' ? 'badge-amber' :
                          task.priority === 'MEDIUM' ? 'badge-cyan' : 'badge-emerald'
                        }`} style={{ fontSize: '0.6rem' }}>
                          {task.priority}
                        </span>
                      </div>
                    </div>

                    {idx < topoResult.executionPipeline.length - 1 && (
                      <ChevronRight size={18} color="#64748B" style={{ flexShrink: 0 }} />
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          )}

          {/* Kahn's Step-by-Step State Inspector */}
          {topoResult.steps && topoResult.steps.length > 0 && (
            <div className="glass-panel" style={{ padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <div>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#F8FAFC' }}>
                    Kahn's Algorithm Step Inspector
                  </h4>
                  <p style={{ fontSize: '0.76rem', color: 'var(--text-muted)', margin: '2px 0 0' }}>
                    Step {topoStepIdx + 1} of {topoResult.steps.length}: {topoResult.steps[topoStepIdx]?.actionMessage}
                  </p>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <button
                    className="btn-secondary"
                    onClick={() => setTopoStepIdx(prev => Math.max(0, prev - 1))}
                    disabled={topoStepIdx === 0}
                    style={{ padding: '6px 10px' }}
                  >
                    <SkipBack size={14} />
                  </button>
                  <span className="font-mono" style={{ fontSize: '0.8rem', minWidth: 40, textAlign: 'center' }}>
                    {topoStepIdx + 1} / {topoResult.steps.length}
                  </span>
                  <button
                    className="btn-secondary"
                    onClick={() => setTopoStepIdx(prev => Math.min(topoResult.steps.length - 1, prev + 1))}
                    disabled={topoStepIdx === topoResult.steps.length - 1}
                    style={{ padding: '6px 10px' }}
                  >
                    <SkipForward size={14} />
                  </button>
                </div>
              </div>

              {/* Step State Breakdown Grid */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 16 }}>
                {/* Zero In-Degree Queue */}
                <div style={{ padding: 14, borderRadius: 8, backgroundColor: 'rgba(15, 23, 42, 0.7)', border: '1px solid var(--border-subtle)' }}>
                  <span style={{ fontSize: '0.72rem', color: '#38BDF8', textTransform: 'uppercase', fontWeight: 600 }}>
                    In-Degree = 0 Queue [Ready Pool]
                  </span>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
                    {topoResult.steps[topoStepIdx]?.zeroInDegreeQueue?.length === 0 ? (
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        Queue Empty {topoResult.deadlockDetected && '(Deadlock)'}
                      </span>
                    ) : (
                      topoResult.steps[topoStepIdx]?.zeroInDegreeQueue?.map((k, i) => (
                        <span key={i} className="font-mono badge badge-cyan">
                          {k}
                        </span>
                      ))
                    )}
                  </div>
                </div>

                {/* Remaining In-Degrees */}
                <div style={{ padding: 14, borderRadius: 8, backgroundColor: 'rgba(15, 23, 42, 0.7)', border: '1px solid var(--border-subtle)' }}>
                  <span style={{ fontSize: '0.72rem', color: '#A78BFA', textTransform: 'uppercase', fontWeight: 600 }}>
                    Current In-Degree Counters
                  </span>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
                    {topoResult.steps[topoStepIdx]?.currentInDegrees && Object.entries(topoResult.steps[topoStepIdx].currentInDegrees).map(([k, deg]) => (
                      <span key={k} className="font-mono" style={{
                        fontSize: '0.72rem',
                        padding: '2px 6px',
                        borderRadius: 4,
                        backgroundColor: deg === 0 ? 'rgba(16, 185, 129, 0.15)' : 'rgba(244, 63, 94, 0.15)',
                        color: deg === 0 ? '#34D399' : '#FB7185',
                        border: `1px solid ${deg === 0 ? 'rgba(16, 185, 129, 0.3)' : 'rgba(244, 63, 94, 0.3)'}`
                      }}>
                        {k}: deg={deg}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BFS TRAVERSAL PLAYBACK TAB */}
      {/* ========================================================================= */}
      {activeEngineTab === 'bfs' && bfsResult && (
        <div>
          {/* Controller Bar */}
          <div className="glass-panel" style={{
            padding: '16px 20px',
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 16
          }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC' }}>
                BFS Level-Order Playback Controller
              </h3>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: 2 }}>
                Current Step: {bfsStepIdx + 1} of {bfsResult.steps.length} &bull; Origin Node: <strong style={{ color: '#38BDF8' }}>{bfsResult.startTaskKey}</strong>
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button
                className="btn-secondary"
                onClick={() => { setBfsStepIdx(0); setBfsPlaying(false); }}
                style={{ padding: '8px 12px' }}
                title="Reset to start"
              >
                <RotateCcw size={15} />
              </button>

              <button
                className="btn-secondary"
                onClick={() => setBfsStepIdx(prev => Math.max(0, prev - 1))}
                disabled={bfsStepIdx === 0}
                style={{ padding: '8px 12px' }}
              >
                <SkipBack size={15} />
              </button>

              <button
                className="btn-primary"
                onClick={() => setBfsPlaying(prev => !prev)}
                style={{ padding: '8px 18px' }}
              >
                {bfsPlaying ? <Pause size={16} /> : <Play size={16} />}
                <span>{bfsPlaying ? 'Pause Playback' : 'Play Traversal'}</span>
              </button>

              <button
                className="btn-secondary"
                onClick={() => setBfsStepIdx(prev => Math.min(bfsResult.steps.length - 1, prev + 1))}
                disabled={bfsStepIdx === bfsResult.steps.length - 1}
                style={{ padding: '8px 12px' }}
              >
                <SkipForward size={15} />
              </button>

              {/* Speed dropdown */}
              <select
                value={bfsSpeed}
                onChange={(e) => setBfsSpeed(Number(e.target.value))}
                style={{
                  padding: '7px 10px',
                  borderRadius: 6,
                  backgroundColor: 'rgba(30, 41, 59, 0.8)',
                  color: '#F8FAFC',
                  border: '1px solid var(--border-subtle)',
                  fontSize: '0.78rem',
                  outline: 'none'
                }}
              >
                <option value={1500}>0.5x Speed</option>
                <option value={1000}>1.0x Speed</option>
                <option value={500}>2.0x Speed</option>
              </select>
            </div>
          </div>

          {/* Playback Snapshot */}
          {bfsResult.steps && bfsResult.steps[bfsStepIdx] && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16 }}>
              {/* Queue State */}
              <div className="glass-panel" style={{ padding: 18 }}>
                <span style={{ fontSize: '0.74rem', color: '#38BDF8', textTransform: 'uppercase', fontWeight: 600 }}>
                  FIFO Exploration Queue [FIFO]
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
                  {bfsResult.steps[bfsStepIdx].queueState.length === 0 ? (
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>[Queue is Empty]</span>
                  ) : (
                    bfsResult.steps[bfsStepIdx].queueState.map((node, i) => (
                      <span key={i} className="font-mono badge badge-cyan" style={{ fontSize: '0.78rem', padding: '4px 10px' }}>
                        {node}
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Visited Nodes */}
              <div className="glass-panel" style={{ padding: 18 }}>
                <span style={{ fontSize: '0.74rem', color: '#34D399', textTransform: 'uppercase', fontWeight: 600 }}>
                  Visited Set Trail ({bfsResult.steps[bfsStepIdx].visitedNodes.length} Nodes)
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
                  {bfsResult.steps[bfsStepIdx].visitedNodes.map((node, i) => (
                    <span key={i} className="font-mono badge badge-emerald" style={{ fontSize: '0.78rem', padding: '4px 10px' }}>
                      {node}
                    </span>
                  ))}
                </div>
              </div>

              {/* Frontier Discovered */}
              <div className="glass-panel" style={{ padding: 18 }}>
                <span style={{ fontSize: '0.74rem', color: '#A78BFA', textTransform: 'uppercase', fontWeight: 600 }}>
                  Discovered Frontier Children
                </span>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
                  {bfsResult.steps[bfsStepIdx].frontierNodes?.length === 0 ? (
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>[No new frontier]</span>
                  ) : (
                    bfsResult.steps[bfsStepIdx].frontierNodes.map((node, i) => (
                      <span key={i} className="font-mono badge badge-purple" style={{ fontSize: '0.78rem', padding: '4px 10px' }}>
                        {node}
                      </span>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. DFS RECURSION CALL STACK TAB */}
      {/* ========================================================================= */}
      {activeEngineTab === 'dfs' && dfsResult && (
        <div>
          <div className="glass-panel" style={{
            padding: '16px 20px',
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 16
          }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC' }}>
                DFS Recursion Stack & Edge Classification
              </h3>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: 2 }}>
                Step {dfsStepIdx + 1} of {dfsResult.steps.length}: {dfsResult.steps[dfsStepIdx]?.actionMessage}
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button
                className="btn-secondary"
                onClick={() => setDfsStepIdx(prev => Math.max(0, prev - 1))}
                disabled={dfsStepIdx === 0}
                style={{ padding: '8px 12px' }}
              >
                <SkipBack size={15} />
              </button>
              <button
                className="btn-primary"
                onClick={() => setDfsPlaying(prev => !prev)}
                style={{ padding: '8px 18px' }}
              >
                {dfsPlaying ? <Pause size={16} /> : <Play size={16} />}
                <span>{dfsPlaying ? 'Pause' : 'Play DFS'}</span>
              </button>
              <button
                className="btn-secondary"
                onClick={() => setDfsStepIdx(prev => Math.min(dfsResult.steps.length - 1, prev + 1))}
                disabled={dfsStepIdx === dfsResult.steps.length - 1}
                style={{ padding: '8px 12px' }}
              >
                <SkipForward size={15} />
              </button>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 16 }}>
            {/* Call Stack Visualizer */}
            <div className="glass-panel" style={{ padding: 18 }}>
              <span style={{ fontSize: '0.74rem', color: '#10B981', textTransform: 'uppercase', fontWeight: 600 }}>
                Active Recursion Call Stack (LIFO)
              </span>
              <div style={{ display: 'flex', flexDirection: 'column-reverse', gap: 6, marginTop: 10 }}>
                {dfsResult.steps[dfsStepIdx]?.callStack.map((node, i) => (
                  <div key={i} className="font-mono glass-card" style={{
                    padding: '8px 12px',
                    borderRadius: 6,
                    borderLeft: '4px solid #10B981',
                    fontSize: '0.8rem',
                    color: '#34D399',
                    display: 'flex',
                    justifyContent: 'space-between'
                  }}>
                    <span>Stack Frame #{i}: {node}</span>
                    <span style={{ color: 'var(--text-muted)' }}>Active</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Discovery & Finish Times */}
            <div className="glass-panel" style={{ padding: 18 }}>
              <span style={{ fontSize: '0.74rem', color: '#A78BFA', textTransform: 'uppercase', fontWeight: 600 }}>
                Discovery & Finish Timestamps d[u] / f[u]
              </span>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', gap: 8, marginTop: 10 }}>
                {Object.keys(dfsResult.discoveryTimes || {}).map((k) => (
                  <div key={k} className="glass-card" style={{ padding: '6px 10px', borderRadius: 6, textAlign: 'center' }}>
                    <span className="font-mono" style={{ fontSize: '0.75rem', fontWeight: 700, color: '#38BDF8' }}>{k}</span>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginTop: 2 }}>
                      d={dfsResult.discoveryTimes[k]} / f={dfsResult.finishTimes[k] || '-'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. MIN-HEAP PRIORITY TASK DISPATCHER TAB */}
      {/* ========================================================================= */}
      {activeEngineTab === 'dispatcher' && dispatchResult && (
        <div>
          {/* Dispatcher Header & Settings */}
          <div className="glass-panel" style={{
            padding: '16px 20px',
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 16
          }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC' }}>
                Adaptive Task Dispatcher (Priority Queue / Min-Heap)
              </h3>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: 2 }}>
                Schedules tasks dynamically into a simulated worker pool by Priority Level, Duration, and Prerequisite Resolution.
              </p>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>Worker Pool Size:</span>
                <select
                  value={workerCount}
                  onChange={(e) => {
                    const c = Number(e.target.value);
                    setWorkerCount(c);
                    runTaskDispatcher(c).then(setDispatchResult);
                  }}
                  style={{
                    padding: '6px 12px',
                    borderRadius: 6,
                    backgroundColor: 'rgba(30, 41, 59, 0.8)',
                    color: '#F8FAFC',
                    border: '1px solid var(--border-subtle)',
                    fontSize: '0.8rem',
                    outline: 'none'
                  }}
                >
                  <option value={2}>2 Concurrent Workers</option>
                  <option value={3}>3 Concurrent Workers</option>
                  <option value={4}>4 Concurrent Workers</option>
                </select>
              </div>

              <div className="badge badge-amber" style={{ fontSize: '0.75rem', padding: '6px 10px' }}>
                Total Makespan: {dispatchResult.totalPipelineDurationHours} Hours
              </div>
            </div>
          </div>

          {/* Worker Gantt Simulation Timeline */}
          <div className="glass-panel" style={{ padding: 20, marginBottom: 20 }}>
            <h4 style={{ fontSize: '0.92rem', fontWeight: 600, color: '#F8FAFC', marginBottom: 14 }}>
              Multi-Worker Execution Gantt Timeline
            </h4>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {Object.keys(dispatchResult.workerWorkloadsHours || {}).map((workerName) => {
                const workerSlots = dispatchResult.scheduleSlots.filter(s => s.workerId === workerName);
                const maxHour = Math.max(1, dispatchResult.totalPipelineDurationHours);

                return (
                  <div key={workerName} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 180, fontSize: '0.78rem', fontWeight: 600, color: '#38BDF8', flexShrink: 0 }}>
                      {workerName}
                    </div>

                    <div style={{
                      flex: 1,
                      height: 42,
                      backgroundColor: 'rgba(15, 23, 42, 0.6)',
                      borderRadius: 8,
                      position: 'relative',
                      overflow: 'hidden',
                      border: '1px solid var(--border-subtle)'
                    }}>
                      {workerSlots.map((slot) => {
                        const leftPercent = (slot.startHour / maxHour) * 100;
                        const widthPercent = (slot.durationHours / maxHour) * 100;

                        return (
                          <div
                            key={slot.taskKey}
                            style={{
                              position: 'absolute',
                              left: `${leftPercent}%`,
                              width: `${Math.max(4, widthPercent)}%`,
                              height: '100%',
                              backgroundColor: slot.priority === 'CRITICAL' ? 'rgba(244, 63, 94, 0.4)' :
                                slot.priority === 'HIGH' ? 'rgba(245, 158, 11, 0.4)' :
                                slot.priority === 'MEDIUM' ? 'rgba(56, 189, 248, 0.4)' : 'rgba(16, 185, 129, 0.4)',
                              border: `1px solid ${slot.priority === 'CRITICAL' ? '#F43F5E' : slot.priority === 'HIGH' ? '#F59E0B' : '#38BDF8'}`,
                              borderRadius: 6,
                              padding: '2px 8px',
                              display: 'flex',
                              flexDirection: 'column',
                              justifyContent: 'center',
                              boxSizing: 'border-box',
                              overflow: 'hidden'
                            }}
                            title={`${slot.taskKey}: ${slot.taskTitle} (${slot.durationHours}h) [Hours: ${slot.startHour} - ${slot.endHour}]`}
                          >
                            <span className="font-mono" style={{ fontSize: '0.72rem', fontWeight: 700, color: '#F8FAFC', whiteSpace: 'nowrap' }}>
                              {slot.taskKey}
                            </span>
                            <span style={{ fontSize: '0.62rem', color: '#CBD5E1', whiteSpace: 'nowrap' }}>
                              {slot.startHour}h - {slot.endHour}h
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Live Heap Operations Stream */}
          <div className="glass-panel" style={{ padding: 20 }}>
            <h4 style={{ fontSize: '0.92rem', fontWeight: 600, color: '#F8FAFC', marginBottom: 12 }}>
              Min-Heap Operations Log ($O(\log V)$ per dispatch)
            </h4>

            <div style={{
              maxHeight: 220,
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: 8,
              paddingRight: 6
            }}>
              {dispatchResult.heapOperations?.map((op, i) => (
                <div key={i} className="font-mono" style={{
                  padding: '8px 12px',
                  borderRadius: 6,
                  backgroundColor: 'rgba(15, 23, 42, 0.7)',
                  border: '1px solid var(--border-subtle)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: '0.76rem'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span className={`badge ${
                      op.operation === 'EXTRACT_MIN' ? 'badge-amber' :
                      op.operation === 'HEAPIFY_UP' ? 'badge-purple' : 'badge-cyan'
                    }`} style={{ fontSize: '0.62rem' }}>
                      {op.operation}
                    </span>
                    <span style={{ color: '#F8FAFC' }}>{op.details}</span>
                  </div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>
                    Heap State: [{op.heapArraySnapshot.join(', ')}]
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
