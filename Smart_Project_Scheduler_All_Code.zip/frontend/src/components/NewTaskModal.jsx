import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { createTask } from '../api/client';

export default function NewTaskModal({ isOpen, onClose, onTaskCreated, papers, prefillPaper }) {
  const [formData, setFormData] = useState({
    taskKey: '',
    title: prefillPaper ? `Implement ${prefillPaper.title.slice(0, 30)}...` : '',
    description: prefillPaper ? `Develop implementation inspired by ${prefillPaper.title}.` : '',
    status: 'READY',
    priority: 'HIGH',
    estimatedDurationHours: 8,
    deadline: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    paperId: prefillPaper ? prefillPaper.id : '',
    paperTitle: prefillPaper ? prefillPaper.title : '',
    colorTag: '#38BDF8',
  });
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    try {
      setSubmitting(true);
      await createTask({
        ...formData,
        estimatedDurationHours: Number(formData.estimatedDurationHours),
        positionX: 300 + Math.random() * 200,
        positionY: 150 + Math.random() * 150,
      });
      onTaskCreated();
      onClose();
    } catch (err) {
      alert('Failed to create task: ' + (err.response?.data?.message || err.message));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(6px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 250,
      padding: 16
    }}>
      <div className="glass-panel" style={{
        maxWidth: 550,
        width: '100%',
        padding: 24,
        borderRadius: 16,
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#F8FAFC' }}>
            Add Execution Task Node
          </h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Task Title
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. FlashAttention Kernel Fusion"
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none'
              }}
            />
          </div>

          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Description
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Technical objectives, algorithmic approach, and expected deliverables..."
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none',
                resize: 'vertical'
              }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Priority Level
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              >
                <option value="CRITICAL">CRITICAL (Top Heap Weight)</option>
                <option value="HIGH">HIGH Priority</option>
                <option value="MEDIUM">MEDIUM Priority</option>
                <option value="LOW">LOW Priority</option>
              </select>
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Estimated Duration (Hours)
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={formData.estimatedDurationHours}
                onChange={(e) => setFormData({ ...formData, estimatedDurationHours: e.target.value })}
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Link Research Paper (Optional)
            </label>
            <select
              value={formData.paperId}
              onChange={(e) => {
                const id = e.target.value;
                const p = papers.find(item => item.id.toString() === id);
                setFormData({
                  ...formData,
                  paperId: id ? Number(id) : null,
                  paperTitle: p ? p.title : '',
                });
              }}
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none'
              }}
            >
              <option value="">None (Standalone Engineering Task)</option>
              {papers.map((p) => (
                <option key={p.id} value={p.id}>{p.title}</option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 12 }}>
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={submitting}>
              <Plus size={16} />
              <span>{submitting ? 'Creating Node...' : 'Add Node to DAG'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
