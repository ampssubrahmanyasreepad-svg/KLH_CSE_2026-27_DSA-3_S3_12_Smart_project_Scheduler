import React, { useState } from 'react';
import { BookOpen, X } from 'lucide-react';
import { createPaper } from '../api/client';

export default function NewPaperModal({ isOpen, onClose, onPaperCreated }) {
  const [formData, setFormData] = useState({
    title: '',
    authors: '',
    publicationYear: new Date().getFullYear(),
    publicationVenue: 'arXiv',
    abstractText: '',
    methodology: '',
    arxivUrl: '',
    tags: 'Deep Learning, Algorithms, Graph Theory'
  });
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.abstractText.trim()) return;

    try {
      setSubmitting(true);
      await createPaper({
        ...formData,
        publicationYear: Number(formData.publicationYear)
      });
      onPaperCreated();
      onClose();
    } catch (err) {
      alert('Failed to save paper: ' + (err.response?.data?.message || err.message));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(6px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 250,
      padding: 16
    }}>
      <div className="glass-panel" style={{
        maxWidth: 620,
        width: '100%',
        maxHeight: '92vh',
        overflowY: 'auto',
        padding: 24,
        borderRadius: 16,
        boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <BookOpen size={20} color="#8B5CF6" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#F8FAFC' }}>
              Add Research Paper
            </h3>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Paper Title
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. RoFormer: Enhanced Transformer with Rotary Position Embedding"
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none'
              }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 10 }}>
            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Authors
              </label>
              <input
                type="text"
                required
                value={formData.authors}
                onChange={(e) => setFormData({ ...formData, authors: e.target.value })}
                placeholder="e.g. Jianlin Su, et al."
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Year
              </label>
              <input
                type="number"
                value={formData.publicationYear}
                onChange={(e) => setFormData({ ...formData, publicationYear: e.target.value })}
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Venue
              </label>
              <input
                type="text"
                value={formData.publicationVenue}
                onChange={(e) => setFormData({ ...formData, publicationVenue: e.target.value })}
                placeholder="e.g. NeurIPS"
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Abstract Text (Indexed by Rabin-Karp)
            </label>
            <textarea
              rows={4}
              required
              value={formData.abstractText}
              onChange={(e) => setFormData({ ...formData, abstractText: e.target.value })}
              placeholder="Paste full research abstract here..."
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none',
                resize: 'vertical'
              }}
            />
          </div>

          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
              Core Methodology & Algorithmic Formulation
            </label>
            <textarea
              rows={2}
              value={formData.methodology}
              onChange={(e) => setFormData({ ...formData, methodology: e.target.value })}
              placeholder="Key equations, algorithmic steps, data structures..."
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#F8FAFC',
                fontSize: '0.86rem',
                outline: 'none',
                resize: 'vertical'
              }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                ArXiv / DOI URL
              </label>
              <input
                type="url"
                value={formData.arxivUrl}
                onChange={(e) => setFormData({ ...formData, arxivUrl: e.target.value })}
                placeholder="https://arxiv.org/abs/..."
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 }}>
                Tags (Comma-separated)
              </label>
              <input
                type="text"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder="NLP, Transformer, Attention"
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: 8,
                  backgroundColor: 'rgba(15, 23, 42, 0.8)',
                  border: '1px solid var(--border-subtle)',
                  color: '#F8FAFC',
                  fontSize: '0.86rem',
                  outline: 'none'
                }}
              />
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 12 }}>
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={submitting}>
              <span>{submitting ? 'Indexing Paper...' : 'Add to Catalog'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
