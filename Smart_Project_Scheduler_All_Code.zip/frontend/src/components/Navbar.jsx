import React from 'react';
import { 
  Network, 
  BookOpen, 
  Cpu, 
  BarChart3, 
  GitFork, 
  Code2, 
  AlertTriangle, 
  RefreshCw, 
  CheckCircle2, 
  Database 
} from 'lucide-react';

export default function Navbar({ 
  activeTab, 
  setActiveTab, 
  deadlockActive, 
  onToggleDeadlock, 
  onSeedData, 
  loadingAction, 
  serverConnected 
}) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'papers', label: 'Research Papers', icon: BookOpen, badge: 'Rabin-Karp' },
    { id: 'dag', label: 'Task DAG Visualizer', icon: GitFork, badge: 'Interactive' },
    { id: 'algorithms', label: 'Algorithmic Engine', icon: Cpu, badge: 'Kahn / BFS / Heap' },
    { id: 'lab', label: 'Algorithm Lab', icon: Code2, badge: 'O(V+E)' },
  ];

  return (
    <header className="glass-panel" style={{
      margin: '12px 16px 0',
      padding: '12px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 12,
      zIndex: 100,
    }}>
      {/* Brand & Concept */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{
          width: 42,
          height: 42,
          borderRadius: 10,
          background: 'linear-gradient(135deg, #0284C7, #8B5CF6)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 0 20px rgba(56, 189, 248, 0.4)'
        }}>
          <Network size={24} color="#FFFFFF" />
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ 
              fontSize: '1.25rem', 
              fontWeight: 800, 
              letterSpacing: '-0.02em',
              background: 'linear-gradient(90deg, #F8FAFC 0%, #38BDF8 60%, #8B5CF6 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              NexusPlan
            </span>
            <span className="badge badge-purple" style={{ fontSize: '0.65rem' }}>
              DSA ENGINE
            </span>
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0 }}>
            Research-Integrated Project & Graph Engine
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '8px 14px',
                borderRadius: 8,
                fontSize: '0.85rem',
                fontWeight: isActive ? 600 : 500,
                color: isActive ? '#38BDF8' : 'var(--text-secondary)',
                backgroundColor: isActive ? 'rgba(56, 189, 248, 0.12)' : 'transparent',
                border: isActive ? '1px solid rgba(56, 189, 248, 0.35)' : '1px solid transparent',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              <Icon size={16} />
              <span>{item.label}</span>
              {item.badge && (
                <span style={{
                  fontSize: '0.65rem',
                  padding: '1px 6px',
                  borderRadius: 4,
                  backgroundColor: isActive ? 'rgba(56, 189, 248, 0.2)' : 'rgba(255, 255, 255, 0.06)',
                  color: isActive ? '#38BDF8' : 'var(--text-muted)'
                }}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Global Quick Actions & Status */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {/* Deadlock Toggle */}
        <button
          onClick={onToggleDeadlock}
          disabled={loadingAction}
          className={deadlockActive ? 'btn-danger' : 'btn-secondary'}
          title="Inject a circular dependency edge (A -> B -> A) to test Kahn's Algorithm Deadlock Detection"
          style={{ padding: '7px 12px', fontSize: '0.78rem' }}
        >
          <AlertTriangle size={15} color={deadlockActive ? '#FDA4AF' : '#F59E0B'} />
          <span>{deadlockActive ? 'Deadlock Injected (A⇄B)' : 'Test Deadlock (A⇄B)'}</span>
        </button>

        {/* Reseed Data */}
        <button
          onClick={onSeedData}
          disabled={loadingAction}
          className="btn-secondary"
          title="Reset database to clean research papers and verified DAG topology"
          style={{ padding: '7px 12px', fontSize: '0.78rem' }}
        >
          <RefreshCw size={14} className={loadingAction ? 'spin' : ''} />
          <span>Reset Sample DAG</span>
        </button>

        {/* Server Connection Status */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '6px 10px',
          borderRadius: 6,
          backgroundColor: 'rgba(255, 255, 255, 0.04)',
          border: '1px solid var(--border-subtle)',
          fontSize: '0.75rem',
          color: serverConnected ? '#34D399' : '#F59E0B'
        }}>
          <div style={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            backgroundColor: serverConnected ? '#10B981' : '#F59E0B',
            boxShadow: serverConnected ? '0 0 8px #10B981' : '0 0 8px #F59E0B'
          }} />
          <span>{serverConnected ? 'Engine Online' : 'Connecting...'}</span>
        </div>
      </div>
    </header>
  );
}
