import React, { useState, useEffect } from 'react';
import { 
  Code2, 
  Cpu, 
  Terminal, 
  Layers, 
  GitBranch, 
  Copy, 
  Check, 
  Activity, 
  FileCode,
  Sparkles,
  Zap,
  Clock
} from 'lucide-react';
import { fetchDiagnostics } from '../api/client';

export default function AlgorithmLabView({ stats }) {
  const [diagnostics, setDiagnostics] = useState(null);
  const [selectedSnippet, setSelectedSnippet] = useState("Kahn's Topological Sort");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchDiagnostics().then(setDiagnostics).catch(console.error);
  }, [stats]);

  const handleCopyCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ padding: '24px 20px', maxWidth: 1400, margin: '0 auto' }}>
      {/* Header */}
      <div className="glass-panel" style={{ padding: 24, marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <h2 style={{ fontSize: '1.4rem', fontWeight: 700, color: '#F8FAFC' }}>
            Graph Engine Diagnostics & Algorithm Lab
          </h2>
          <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
            Complexity Analysis O(V+E)
          </span>
        </div>
        <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: 4 }}>
          Live mathematical diagnostics, graph theory metrics, and Java backend code inspector drawers.
        </p>
      </div>

      {/* Complexity & Graph Theory Metrics Grid */}
      {diagnostics && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: 16,
          marginBottom: 24
        }}>
          {/* Metric 1 */}
          <div className="glass-card" style={{ padding: 18 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Time Complexity
            </span>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#38BDF8', marginTop: 6 }} className="font-mono">
              {diagnostics.timeComplexityNotation}
            </div>
            <p style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', marginTop: 4 }}>
              Linear traversal over vertices and edges
            </p>
          </div>

          {/* Metric 2 */}
          <div className="glass-card" style={{ padding: 18 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Graph Density D
            </span>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#A78BFA', marginTop: 6 }} className="font-mono">
              {diagnostics.graphDensity}
            </div>
            <p style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', marginTop: 4 }}>
              D = |E| / (|V|(|V|-1)) for directed DAG
            </p>
          </div>

          {/* Metric 3 */}
          <div className="glass-card" style={{ padding: 18 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Critical Path Length
            </span>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#FBBF24', marginTop: 6 }} className="font-mono">
              {diagnostics.criticalPathLengthHours} Hours
            </div>
            <p style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', marginTop: 4 }}>
              Longest dependency chain via Dynamic Programming
            </p>
          </div>

          {/* Metric 4 */}
          <div className="glass-card" style={{ padding: 18 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Max In / Out Degree
            </span>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#34D399', marginTop: 6 }} className="font-mono">
              In: {diagnostics.maxInDegree} / Out: {diagnostics.maxOutDegree}
            </div>
            <p style={{ fontSize: '0.76rem', color: 'var(--text-secondary)', marginTop: 4 }}>
              Prerequisite fan-in / fan-out bottlenecks
            </p>
          </div>
        </div>
      )}

      {/* Two Column Layout: Complexity Comparison Table + Code Inspector Drawer */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(460px, 1fr))', gap: 20 }}>
        {/* Left: Theoretical Complexity Matrix */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <Activity size={18} color="#38BDF8" />
            <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#F8FAFC' }}>
              Theoretical Complexity Benchmarks
            </h3>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.1)', textAlign: 'left', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '8px 10px' }}>Algorithm</th>
                  <th style={{ padding: '8px 10px' }}>Complexity Profile</th>
                  <th style={{ padding: '8px 10px' }}>Application in NexusPlan</th>
                </tr>
              </thead>
              <tbody>
                {diagnostics?.theoreticalComplexities && Object.entries(diagnostics.theoreticalComplexities).map(([algo, comp]) => (
                  <tr key={algo} style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.04)' }}>
                    <td style={{ padding: '10px 10px', fontWeight: 600, color: '#F8FAFC' }}>
                      {algo}
                    </td>
                    <td style={{ padding: '10px 10px', color: '#38BDF8' }} className="font-mono">
                      {comp}
                    </td>
                    <td style={{ padding: '10px 10px', color: 'var(--text-secondary)' }}>
                      {algo.includes('Topological') ? 'Pipeline scheduling & cycle detection' :
                       algo.includes('BFS') ? 'Level-order breadth exploration' :
                       algo.includes('DFS') ? 'Deep branch call-stack inspection' :
                       algo.includes('Heap') ? 'Optimal task worker allocation' :
                       algo.includes('Rabin') ? 'Fast research paper abstract search' : 'Longest path analysis'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Engine Terminal Log Mock */}
          <div style={{ marginTop: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Terminal size={16} color="#A78BFA" />
              <h4 style={{ fontSize: '0.86rem', fontWeight: 600, color: '#F8FAFC' }}>
                Live Engine Execution Telemetry
              </h4>
            </div>

            <div className="font-mono" style={{
              padding: 14,
              borderRadius: 8,
              backgroundColor: '#030712',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              fontSize: '0.74rem',
              color: '#34D399',
              lineHeight: 1.6,
              maxHeight: 160,
              overflowY: 'auto'
            }}>
              <div>[INFO] [GraphEngine] Initialized Directed Graph: |V| = {stats?.graphVertexCount}, |E| = {stats?.graphEdgeCount}</div>
              <div>[INFO] [RabinKarp] Rolling hash initialized with prime base d=256, modulus q=1000000007</div>
              <div>[INFO] [KahnAlgorithm] Computed in-degrees array. Evaluated DAG acyclicity: {stats?.dagValid ? 'PASSED' : 'DEADLOCK DETECTED'}</div>
              <div>[INFO] [MinHeapDispatcher] Priority comparator mounted: CRITICAL &gt; HIGH &gt; MEDIUM &gt; LOW</div>
              <div>[INFO] [CPM] Critical path dynamic programming complete: {stats?.criticalPathHours} hours total makespan</div>
            </div>
          </div>
        </div>

        {/* Right: Code Inspector Drawer */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <FileCode size={18} color="#8B5CF6" />
              <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#F8FAFC' }}>
                Backend Code Inspector Drawer
              </h3>
            </div>

            <button
              className="btn-secondary"
              onClick={() => handleCopyCode(diagnostics?.algorithmCodeSnippets?.[selectedSnippet] || '')}
              style={{ padding: '6px 12px', fontSize: '0.76rem' }}
            >
              {copied ? <Check size={14} color="#34D399" /> : <Copy size={14} />}
              <span>{copied ? 'Copied' : 'Copy Code'}</span>
            </button>
          </div>

          {/* Code Tabs */}
          <div style={{ display: 'flex', gap: 6, overflowX: 'auto', marginBottom: 12 }}>
            {diagnostics?.algorithmCodeSnippets && Object.keys(diagnostics.algorithmCodeSnippets).map((key) => (
              <button
                key={key}
                onClick={() => setSelectedSnippet(key)}
                style={{
                  padding: '6px 12px',
                  borderRadius: 6,
                  fontSize: '0.78rem',
                  fontWeight: selectedSnippet === key ? 600 : 400,
                  backgroundColor: selectedSnippet === key ? 'rgba(139, 92, 246, 0.2)' : 'rgba(255, 255, 255, 0.04)',
                  color: selectedSnippet === key ? '#C4B5FD' : 'var(--text-muted)',
                  border: selectedSnippet === key ? '1px solid rgba(139, 92, 246, 0.4)' : '1px solid transparent',
                  cursor: 'pointer',
                  whiteSpace: 'nowrap'
                }}
              >
                {key}
              </button>
            ))}
          </div>

          {/* Syntax Highlighted Box */}
          <pre className="font-mono" style={{
            padding: 16,
            borderRadius: 8,
            backgroundColor: '#030712',
            border: '1px solid rgba(139, 92, 246, 0.3)',
            color: '#BAE6FD',
            fontSize: '0.8rem',
            lineHeight: 1.5,
            overflowX: 'auto',
            maxHeight: 340
          }}>
            <code>
              {diagnostics?.algorithmCodeSnippets?.[selectedSnippet] || '// Select an algorithm to inspect implementation'}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
}
