import React, { useState, useRef, useEffect } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  RotateCcw, 
  Plus, 
  Link2, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Layers, 
  Play, 
  ChevronRight,
  Info
} from 'lucide-react';
import { updateTaskPosition, addDependency, deleteDependency } from '../api/client';

export default function DagVisualizerView({ 
  tasks, 
  dependencies, 
  deadlockActive, 
  onToggleDeadlock, 
  onAddTaskClick, 
  onRefreshData,
  topologicalResult
}) {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 40, y: 40 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  // Node Dragging State
  const [draggingTaskId, setDraggingTaskId] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [localTaskPositions, setLocalTaskPositions] = useState({});

  // Selection
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [connectSourceId, setConnectSourceId] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);

  // Sync positions from tasks
  useEffect(() => {
    const posMap = {};
    tasks.forEach((t) => {
      posMap[t.id] = {
        x: t.positionX || 100,
        y: t.positionY || 100
      };
    });
    setLocalTaskPositions(posMap);
  }, [tasks]);

  // Selected task object
  const selectedTask = tasks.find(t => t.id === selectedTaskId);

  // Calculate upstream and downstream for selected task
  const upstreamDependencies = dependencies.filter(d => d.targetTaskId === selectedTaskId);
  const downstreamDependencies = dependencies.filter(d => d.sourceTaskId === selectedTaskId);

  // Cycle edges if deadlock is detected
  const isDeadlockActive = deadlockActive || topologicalResult?.deadlockDetected;
  const cycleNodes = topologicalResult?.cycleNodes || [];

  // Pan handlers
  const handleMouseDown = (e) => {
    if (e.target.closest('.dag-node') || e.target.closest('.toolbar-panel')) return;
    setIsPanning(true);
    setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
    } else if (draggingTaskId) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const newX = (e.clientX - containerRect.left - pan.x) / zoom - dragOffset.x;
      const newY = (e.clientY - containerRect.top - pan.y) / zoom - dragOffset.y;

      setLocalTaskPositions(prev => ({
        ...prev,
        [draggingTaskId]: { x: Math.max(20, newX), y: Math.max(20, newY) }
      }));
    }
  };

  const handleMouseUp = async () => {
    if (isPanning) {
      setIsPanning(false);
    }
    if (draggingTaskId) {
      const currentPos = localTaskPositions[draggingTaskId];
      if (currentPos) {
        try {
          await updateTaskPosition(draggingTaskId, currentPos.x, currentPos.y);
        } catch (err) {
          console.error('Failed to save node position:', err);
        }
      }
      setDraggingTaskId(null);
    }
  };

  // Node Drag Start
  const handleNodeMouseDown = (e, taskId) => {
    e.stopPropagation();
    if (isConnecting) {
      handleNodeConnectClick(taskId);
      return;
    }
    setSelectedTaskId(taskId);
    setDraggingTaskId(taskId);

    const taskPos = localTaskPositions[taskId] || { x: 0, y: 0 };
    const containerRect = containerRef.current.getBoundingClientRect();
    const mouseX = (e.clientX - containerRect.left - pan.x) / zoom;
    const mouseY = (e.clientY - containerRect.top - pan.y) / zoom;

    setDragOffset({
      x: mouseX - taskPos.x,
      y: mouseY - taskPos.y
    });
  };

  // Edge connection
  const handleStartConnect = () => {
    if (selectedTaskId) {
      setConnectSourceId(selectedTaskId);
      setIsConnecting(true);
    }
  };

  const handleNodeConnectClick = async (targetId) => {
    if (connectSourceId && connectSourceId !== targetId) {
      try {
        await addDependency(connectSourceId, targetId, 'HARD', 'Precedes');
        onRefreshData();
      } catch (err) {
        alert(err.response?.data?.error || 'Failed to add dependency');
      }
    }
    setIsConnecting(false);
    setConnectSourceId(null);
  };

  const handleDeleteEdge = async (depId) => {
    try {
      await deleteDependency(depId);
      onRefreshData();
    } catch (err) {
      console.error(err);
    }
  };

  // Zoom controls
  const handleZoomIn = () => setZoom(prev => Math.min(2, prev + 0.15));
  const handleZoomOut = () => setZoom(prev => Math.max(0.4, prev - 0.15));
  const handleResetZoom = () => {
    setZoom(1);
    setPan({ x: 40, y: 40 });
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: 'calc(100vh - 110px)', overflow: 'hidden' }}>
      {/* Visualizer Floating Controls Toolbar */}
      <div className="glass-panel toolbar-panel" style={{
        position: 'absolute',
        top: 20,
        left: 24,
        zIndex: 20,
        padding: '8px 14px',
        display: 'flex',
        alignItems: 'center',
        gap: 12
      }}>
        {/* Zoom */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <button className="btn-secondary" onClick={handleZoomIn} style={{ padding: '6px 8px' }} title="Zoom In">
            <ZoomIn size={15} />
          </button>
          <button className="btn-secondary" onClick={handleZoomOut} style={{ padding: '6px 8px' }} title="Zoom Out">
            <ZoomOut size={15} />
          </button>
          <button className="btn-secondary" onClick={handleResetZoom} style={{ padding: '6px 8px' }} title="Reset View">
            <RotateCcw size={15} />
          </button>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', minWidth: 40, textAlign: 'center' }}>
            {Math.round(zoom * 100)}%
          </span>
        </div>

        <div style={{ width: 1, height: 20, backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />

        {/* Action Buttons */}
        <button className="btn-primary" onClick={onAddTaskClick} style={{ padding: '6px 12px', fontSize: '0.78rem' }}>
          <Plus size={14} />
          <span>Add Task Node</span>
        </button>

        <button 
          className={isConnecting ? 'btn-danger' : 'btn-secondary'}
          onClick={isConnecting ? () => setIsConnecting(false) : handleStartConnect}
          disabled={!selectedTaskId && !isConnecting}
          style={{ padding: '6px 12px', fontSize: '0.78rem' }}
          title={selectedTaskId ? `Connect ${selectedTask?.taskKey} to another task` : 'Select a node first to connect edge'}
        >
          <Link2 size={14} />
          <span>{isConnecting ? 'Cancel Connect' : 'Connect Edge'}</span>
        </button>

        <button
          onClick={onToggleDeadlock}
          className={isDeadlockActive ? 'btn-danger' : 'btn-secondary'}
          style={{ padding: '6px 12px', fontSize: '0.78rem' }}
        >
          <AlertTriangle size={14} color={isDeadlockActive ? '#FDA4AF' : '#F59E0B'} />
          <span>{isDeadlockActive ? 'Clear Deadlock' : 'Inject Deadlock (A⇄B)'}</span>
        </button>

        {isConnecting && (
          <span style={{ fontSize: '0.75rem', color: '#38BDF8', animation: 'pulseGlow 1s infinite' }}>
            Click target node to create directed edge &rarr;
          </span>
        )}
      </div>

      {/* Deadlock Banner Alert */}
      {isDeadlockActive && (
        <div style={{
          position: 'absolute',
          top: 76,
          left: 24,
          zIndex: 20,
          padding: '8px 16px',
          borderRadius: 8,
          backgroundColor: 'rgba(244, 63, 94, 0.2)',
          border: '1px solid #F43F5E',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          color: '#FDA4AF',
          fontSize: '0.82rem',
          boxShadow: '0 4px 20px rgba(244, 63, 94, 0.3)'
        }}>
          <AlertTriangle size={16} color="#FB7185" />
          <span>
            <strong>Deadlock Warning:</strong> Circular dependency present ({cycleNodes.join(' ➔ ')}). Edges highlighted in neon red.
          </span>
        </div>
      )}

      {/* Legend & Instructions Panel */}
      <div className="glass-panel" style={{
        position: 'absolute',
        bottom: 20,
        left: 24,
        zIndex: 20,
        padding: '10px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        fontSize: '0.75rem',
        color: 'var(--text-secondary)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#38BDF8' }} />
          <span>Directional Edge (Prerequisite &rarr; Dependent)</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: '#F43F5E' }} />
          <span>Circular Deadlock Edge</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Info size={13} color="#94A3B8" />
          <span>Drag nodes to reposition &bull; Scroll/drag canvas to pan</span>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        style={{
          width: '100%',
          height: '100%',
          cursor: isPanning ? 'grabbing' : isConnecting ? 'crosshair' : 'grab',
          position: 'relative',
          userSelect: 'none',
        }}
      >
        <svg
          style={{
            width: '100%',
            height: '100%',
            position: 'absolute',
            top: 0,
            left: 0,
            overflow: 'visible',
            pointerEvents: 'none',
          }}
        >
          <defs>
            {/* Standard Arrow Marker */}
            <marker
              id="arrow-cyan"
              viewBox="0 0 10 10"
              refX="18"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#38BDF8" />
            </marker>
            {/* Cycle Deadlock Arrow Marker */}
            <marker
              id="arrow-rose"
              viewBox="0 0 10 10"
              refX="18"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#F43F5E" />
            </marker>
            {/* Selected Active Arrow Marker */}
            <marker
              id="arrow-purple"
              viewBox="0 0 10 10"
              refX="18"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#A78BFA" />
            </marker>
          </defs>

          <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
            {/* Directed Edges */}
            {dependencies.map((dep) => {
              const srcPos = localTaskPositions[dep.sourceTaskId];
              const tgtPos = localTaskPositions[dep.targetTaskId];
              if (!srcPos || !tgtPos) return null;

              const srcTask = tasks.find(t => t.id === dep.sourceTaskId);
              const tgtTask = tasks.find(t => t.id === dep.targetTaskId);

              // Detect if this edge is part of circular deadlock
              const isCycleEdge = isDeadlockActive && 
                cycleNodes.includes(srcTask?.taskKey) && 
                cycleNodes.includes(tgtTask?.taskKey);

              const isConnectedToSelected = selectedTaskId && 
                (dep.sourceTaskId === selectedTaskId || dep.targetTaskId === selectedTaskId);

              // Calculate start and end coordinates with node offset
              const x1 = srcPos.x + 105;
              const y1 = srcPos.y + 45;
              const x2 = tgtPos.x + 105;
              const y2 = tgtPos.y + 45;

              // Cubic bezier control points for smooth curves
              const dx = x2 - x1;
              const dy = y2 - y1;
              const cx1 = x1 + Math.max(40, dx * 0.5);
              const cy1 = y1;
              const cx2 = x2 - Math.max(40, dx * 0.5);
              const cy2 = y2;

              const pathData = `M ${x1} ${y1} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x2} ${y2}`;

              return (
                <g key={dep.id}>
                  {/* Background glow path */}
                  <path
                    d={pathData}
                    fill="none"
                    stroke={isCycleEdge ? 'rgba(244, 63, 94, 0.4)' : isConnectedToSelected ? 'rgba(139, 92, 246, 0.4)' : 'rgba(56, 189, 248, 0.15)'}
                    strokeWidth={isCycleEdge ? 6 : 4}
                  />

                  {/* Main animated stroke */}
                  <path
                    d={pathData}
                    fill="none"
                    stroke={isCycleEdge ? '#F43F5E' : isConnectedToSelected ? '#A78BFA' : '#38BDF8'}
                    strokeWidth={isCycleEdge ? 2.5 : 1.8}
                    className={isCycleEdge ? 'edge-cycle' : 'edge-animated'}
                    markerEnd={isCycleEdge ? 'url(#arrow-rose)' : isConnectedToSelected ? 'url(#arrow-purple)' : 'url(#arrow-cyan)'}
                  />

                  {/* Edge label pill if selected */}
                  {isConnectedToSelected && (
                    <text
                      x={(x1 + x2) / 2}
                      y={(y1 + y2) / 2 - 8}
                      fill="#BAE6FD"
                      fontSize={10}
                      textAnchor="middle"
                      className="font-mono"
                    >
                      {dep.dependencyType}
                    </text>
                  )}
                </g>
              );
            })}
          </g>
        </svg>

        {/* Task Nodes Rendered in Transformed HTML Layer */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: '0 0',
          }}
        >
          {tasks.map((task) => {
            const pos = localTaskPositions[task.id] || { x: 100, y: 100 };
            const isSelected = selectedTaskId === task.id;
            const isDeadlockNode = isDeadlockActive && cycleNodes.includes(task.taskKey);

            return (
              <div
                key={task.id}
                className={`dag-node glass-card ${isSelected ? 'node-active' : ''} ${isDeadlockNode ? 'node-deadlock' : ''}`}
                onMouseDown={(e) => handleNodeMouseDown(e, task.id)}
                style={{
                  position: 'absolute',
                  left: pos.x,
                  top: pos.y,
                  width: 210,
                  padding: '12px 14px',
                  borderRadius: 12,
                  cursor: isConnecting ? 'crosshair' : 'move',
                  zIndex: isSelected ? 15 : 5,
                  borderColor: isDeadlockNode 
                    ? '#F43F5E' 
                    : isSelected 
                    ? '#38BDF8' 
                    : 'var(--border-subtle)',
                  boxShadow: isDeadlockNode 
                    ? '0 0 25px rgba(244, 63, 94, 0.4)' 
                    : isSelected 
                    ? '0 0 20px rgba(56, 189, 248, 0.35)' 
                    : '0 8px 24px rgba(0, 0, 0, 0.3)',
                  borderLeft: `5px solid ${isDeadlockNode ? '#F43F5E' : task.colorTag || '#38BDF8'}`,
                }}
              >
                {/* Header: Key & Priority */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span className="font-mono" style={{ fontSize: '0.8rem', fontWeight: 700, color: '#38BDF8' }}>
                    {task.taskKey}
                  </span>
                  <span className={`badge ${
                    task.priority === 'CRITICAL' ? 'badge-rose' :
                    task.priority === 'HIGH' ? 'badge-amber' :
                    task.priority === 'MEDIUM' ? 'badge-cyan' : 'badge-emerald'
                  }`} style={{ fontSize: '0.62rem' }}>
                    {task.priority}
                  </span>
                </div>

                {/* Title */}
                <h4 style={{ 
                  fontSize: '0.84rem', 
                  fontWeight: 600, 
                  color: '#F8FAFC', 
                  lineHeight: 1.3,
                  marginBottom: 8,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  {task.title}
                </h4>

                {/* Metadata row */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Clock size={12} />
                    <span>{task.estimatedDurationHours}h</span>
                  </span>
                  <span className={`badge ${
                    task.status === 'COMPLETED' ? 'badge-emerald' :
                    task.status === 'IN_PROGRESS' ? 'badge-purple' :
                    task.status === 'READY' ? 'badge-cyan' : 'badge-amber'
                  }`} style={{ fontSize: '0.62rem' }}>
                    {task.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Task Details Drawer (Right Side) */}
      {selectedTask && (
        <div className="glass-panel" style={{
          position: 'absolute',
          top: 20,
          right: 24,
          bottom: 20,
          width: 330,
          zIndex: 30,
          padding: 20,
          overflowY: 'auto',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          animation: 'fadeIn 0.2s ease',
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.6)'
        }}>
          <div>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <span className="font-mono" style={{ fontSize: '0.88rem', fontWeight: 700, color: '#38BDF8' }}>
                  {selectedTask.taskKey}
                </span>
                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC', marginTop: 2 }}>
                  {selectedTask.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedTaskId(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '1.2rem', cursor: 'pointer' }}
              >
                &times;
              </button>
            </div>

            {/* Badges */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              <span className={`badge ${
                selectedTask.priority === 'CRITICAL' ? 'badge-rose' :
                selectedTask.priority === 'HIGH' ? 'badge-amber' :
                selectedTask.priority === 'MEDIUM' ? 'badge-cyan' : 'badge-emerald'
              }`}>
                {selectedTask.priority}
              </span>
              <span className="badge badge-purple">
                {selectedTask.status}
              </span>
              <span className="badge badge-cyan">
                {selectedTask.estimatedDurationHours} Hours
              </span>
            </div>

            {/* Description */}
            <div style={{ marginBottom: 16 }}>
              <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Description
              </span>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', marginTop: 4, lineHeight: 1.5 }}>
                {selectedTask.description}
              </p>
            </div>

            {/* Linked Research Paper */}
            {selectedTask.paperTitle && (
              <div style={{
                padding: '10px 12px',
                borderRadius: 8,
                backgroundColor: 'rgba(139, 92, 246, 0.08)',
                border: '1px solid rgba(139, 92, 246, 0.25)',
                marginBottom: 16
              }}>
                <span style={{ fontSize: '0.7rem', color: '#A78BFA', textTransform: 'uppercase', fontWeight: 600 }}>
                  Linked Research Paper
                </span>
                <p style={{ fontSize: '0.8rem', color: '#F8FAFC', marginTop: 2, fontWeight: 500 }}>
                  {selectedTask.paperTitle}
                </p>
              </div>
            )}

            {/* Upstream Prerequisites (Incoming) */}
            <div style={{ marginBottom: 16 }}>
              <span style={{ fontSize: '0.72rem', color: '#38BDF8', textTransform: 'uppercase', fontWeight: 600 }}>
                Prerequisites (In-Degree: {upstreamDependencies.length})
              </span>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 6 }}>
                {upstreamDependencies.length === 0 ? (
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    No prerequisites (Root origin node)
                  </span>
                ) : (
                  upstreamDependencies.map(dep => {
                    const src = tasks.find(t => t.id === dep.sourceTaskId);
                    return (
                      <div key={dep.id} style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '6px 10px',
                        borderRadius: 6,
                        backgroundColor: 'rgba(56, 189, 248, 0.08)',
                        border: '1px solid rgba(56, 189, 248, 0.2)',
                        fontSize: '0.76rem'
                      }}>
                        <span className="font-mono" style={{ color: '#38BDF8' }}>
                          {src?.taskKey}: {src?.title.slice(0, 16)}...
                        </span>
                        <button
                          onClick={() => handleDeleteEdge(dep.id)}
                          style={{ background: 'none', border: 'none', color: '#FB7185', cursor: 'pointer' }}
                          title="Remove prerequisite dependency"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Downstream Dependents (Outgoing) */}
            <div style={{ marginBottom: 16 }}>
              <span style={{ fontSize: '0.72rem', color: '#A78BFA', textTransform: 'uppercase', fontWeight: 600 }}>
                Dependents (Out-Degree: {downstreamDependencies.length})
              </span>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 6 }}>
                {downstreamDependencies.length === 0 ? (
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    No dependents (Leaf pipeline node)
                  </span>
                ) : (
                  downstreamDependencies.map(dep => {
                    const tgt = tasks.find(t => t.id === dep.targetTaskId);
                    return (
                      <div key={dep.id} style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '6px 10px',
                        borderRadius: 6,
                        backgroundColor: 'rgba(139, 92, 246, 0.08)',
                        border: '1px solid rgba(139, 92, 246, 0.2)',
                        fontSize: '0.76rem'
                      }}>
                        <span className="font-mono" style={{ color: '#A78BFA' }}>
                          &rarr; {tgt?.taskKey}: {tgt?.title.slice(0, 16)}...
                        </span>
                        <button
                          onClick={() => handleDeleteEdge(dep.id)}
                          style={{ background: 'none', border: 'none', color: '#FB7185', cursor: 'pointer' }}
                          title="Remove dependency"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Quick Connect & Close Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 14, borderTop: '1px solid rgba(255, 255, 255, 0.08)' }}>
            <button
              className="btn-primary"
              onClick={handleStartConnect}
              style={{ width: '100%', justifyContent: 'center' }}
            >
              <Link2 size={15} />
              <span>Connect to Dependent Task</span>
            </button>
            <button
              className="btn-secondary"
              onClick={() => setSelectedTaskId(null)}
              style={{ width: '100%', justifyContent: 'center' }}
            >
              Close Inspector
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
