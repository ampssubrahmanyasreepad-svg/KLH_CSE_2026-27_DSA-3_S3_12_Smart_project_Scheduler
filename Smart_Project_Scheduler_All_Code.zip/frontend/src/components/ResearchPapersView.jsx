import React, { useState, useEffect } from 'react';
import { 
  Search, 
  BookOpen, 
  ExternalLink, 
  Plus, 
  Cpu, 
  Hash, 
  Sparkles, 
  Clock, 
  Tag, 
  FileText, 
  CheckCircle, 
  PlusCircle, 
  Layers 
} from 'lucide-react';
import { searchPapersRabinKarp } from '../api/client';

export default function ResearchPapersView({ 
  papers, 
  onAddPaperClick, 
  onCreateTaskFromPaper 
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedPaper, setSelectedPaper] = useState(null);

  // Trigger Rabin-Karp backend search whenever searchQuery changes
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResult(null);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setIsSearching(true);
        const res = await searchPapersRabinKarp(searchQuery);
        setSearchResult(res);
      } catch (err) {
        console.error('Rabin-Karp search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Helper to highlight matches in text
  const renderHighlightedText = (text, query) => {
    if (!query || !query.trim()) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, index) => 
      part.toLowerCase() === query.toLowerCase() ? (
        <mark 
          key={index}
          style={{
            backgroundColor: 'rgba(56, 189, 248, 0.35)',
            color: '#38BDF8',
            padding: '2px 4px',
            borderRadius: 4,
            fontWeight: 700,
            border: '1px solid rgba(56, 189, 248, 0.6)'
          }}
        >
          {part}
        </mark>
      ) : part
    );
  };

  return (
    <div style={{ padding: '24px 20px', maxWidth: 1400, margin: '0 auto' }}>
      {/* Header & Rabin-Karp Search Bar */}
      <div className="glass-panel" style={{ padding: 24, marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 700, color: '#F8FAFC' }}>
                Research Papers Catalog
              </h2>
              <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>
                Rabin-Karp Search Engine
              </span>
            </div>
            <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: 4 }}>
              Query full paper abstracts using rolling-hash pattern matching with $O(N + M)$ average time complexity.
            </p>
          </div>

          <button 
            className="btn-primary"
            onClick={onAddPaperClick}
          >
            <Plus size={16} />
            <span>Add Research Paper</span>
          </button>
        </div>

        {/* Search Input Box */}
        <div style={{ marginTop: 20, position: 'relative' }}>
          <div style={{
            position: 'absolute',
            left: 14,
            top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--text-muted)',
            display: 'flex',
            alignItems: 'center'
          }}>
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Search abstracts & methodologies (e.g. 'attention', 'residual', 'tiling', 'mapreduce', 'gpu')..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '12px 16px 12px 44px',
              backgroundColor: 'rgba(15, 23, 42, 0.8)',
              border: '1px solid rgba(56, 189, 248, 0.25)',
              borderRadius: 10,
              color: '#F8FAFC',
              fontSize: '0.92rem',
              outline: 'none',
              boxShadow: '0 4px 20px rgba(0, 0, 0, 0.25)',
              transition: 'all 0.2s ease',
            }}
            onFocus={(e) => e.target.style.borderColor = '#38BDF8'}
            onBlur={(e) => e.target.style.borderColor = 'rgba(56, 189, 248, 0.25)'}
          />
          {isSearching && (
            <div style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', fontSize: '0.75rem', color: '#38BDF8' }}>
              Computing hash...
            </div>
          )}
        </div>

        {/* Live Rabin-Karp Diagnostics Metrics Strip */}
        {searchResult && searchQuery && (
          <div style={{
            marginTop: 16,
            padding: '12px 16px',
            backgroundColor: 'rgba(15, 23, 42, 0.6)',
            borderRadius: 8,
            border: '1px solid rgba(139, 92, 246, 0.25)',
            display: 'flex',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 20,
            fontSize: '0.8rem'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#38BDF8' }}>
              <Sparkles size={15} />
              <span>Total Matches: <strong>{searchResult.totalMatches}</strong></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#A78BFA' }}>
              <Clock size={15} />
              <span>Execution Time: <strong>{searchResult.executionTimeMicros} &mu;s</strong></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#34D399' }}>
              <Hash size={15} />
              <span>Hash Comparisons: <strong>{searchResult.totalHashComparisons}</strong></span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#FBBF24' }}>
              <Cpu size={15} />
              <span>Spurious Collisions: <strong>{searchResult.spuriousHits}</strong></span>
            </div>
            <div style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: '0.72rem' }}>
              Polynomial Modulus: <code className="font-mono" style={{ color: '#38BDF8' }}>q = 10^9 + 7</code>, Base: <code className="font-mono" style={{ color: '#38BDF8' }}>d = 256</code>
            </div>
          </div>
        )}
      </div>

      {/* Main Papers Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))',
        gap: 20,
      }}>
        {papers.map((paper) => {
          // Check if this paper has search hits
          const matchData = searchResult?.matches?.find(m => m.paperId === paper.id);

          return (
            <div 
              key={paper.id}
              className="glass-card"
              style={{
                padding: 20,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                borderColor: matchData ? 'rgba(56, 189, 248, 0.4)' : undefined,
                boxShadow: matchData ? '0 0 20px rgba(56, 189, 248, 0.1)' : undefined,
              }}
            >
              <div>
                {/* Meta header */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
                      {paper.publicationVenue || 'arXiv'}
                    </span>
                    <span className="badge badge-purple" style={{ fontSize: '0.7rem' }}>
                      {paper.publicationYear}
                    </span>
                  </div>
                  {matchData && (
                    <span className="badge badge-emerald" style={{ fontSize: '0.68rem' }}>
                      {matchData.matchIndices.length} Matches Found
                    </span>
                  )}
                </div>

                {/* Title */}
                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#F8FAFC', lineHeight: 1.4, marginBottom: 8 }}>
                  {renderHighlightedText(paper.title, searchQuery)}
                </h3>

                {/* Authors */}
                <p style={{ fontSize: '0.78rem', color: '#94A3B8', marginBottom: 12 }}>
                  {paper.authors}
                </p>

                {/* Abstract Text */}
                <p style={{ 
                  fontSize: '0.82rem', 
                  color: 'var(--text-secondary)', 
                  lineHeight: 1.6,
                  display: '-webkit-box',
                  WebkitLineClamp: 4,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                  marginBottom: 14 
                }}>
                  {renderHighlightedText(paper.abstractText, searchQuery)}
                </p>

                {/* Methodology snippet if present */}
                {paper.methodology && (
                  <div style={{
                    padding: '8px 12px',
                    borderRadius: 6,
                    backgroundColor: 'rgba(56, 189, 248, 0.05)',
                    border: '1px solid rgba(56, 189, 248, 0.15)',
                    fontSize: '0.76rem',
                    color: '#BAE6FD',
                    marginBottom: 14
                  }}>
                    <strong style={{ color: '#38BDF8' }}>Methodology: </strong>
                    {renderHighlightedText(paper.methodology, searchQuery)}
                  </div>
                )}

                {/* Tags */}
                {paper.tags && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
                    {paper.tags.split(',').map((tag, i) => (
                      <span 
                        key={i} 
                        style={{
                          fontSize: '0.68rem',
                          padding: '2px 8px',
                          borderRadius: 4,
                          backgroundColor: 'rgba(255, 255, 255, 0.05)',
                          color: '#94A3B8',
                          border: '1px solid rgba(255, 255, 255, 0.08)'
                        }}
                      >
                        {tag.trim()}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                paddingTop: 12,
                borderTop: '1px solid rgba(255, 255, 255, 0.06)'
              }}>
                <button
                  className="btn-secondary"
                  onClick={() => setSelectedPaper(paper)}
                  style={{ fontSize: '0.78rem', padding: '6px 12px' }}
                >
                  <FileText size={14} />
                  <span>Full Abstract</span>
                </button>

                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    className="btn-primary"
                    onClick={() => onCreateTaskFromPaper(paper)}
                    title="Generate actionable engineering execution task from this paper"
                    style={{ fontSize: '0.78rem', padding: '6px 12px' }}
                  >
                    <PlusCircle size={14} />
                    <span>Link to Task</span>
                  </button>

                  {paper.arxivUrl && (
                    <a
                      href={paper.arxivUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-secondary"
                      style={{ padding: '6px 10px', color: '#94A3B8' }}
                      title="Open Original Paper"
                    >
                      <ExternalLink size={14} />
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Paper Details Modal */}
      {selectedPaper && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 200,
          padding: 20
        }}>
          <div className="glass-panel" style={{
            maxWidth: 750,
            width: '100%',
            maxHeight: '90vh',
            overflowY: 'auto',
            padding: 28,
            borderRadius: 16
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <span className="badge badge-purple" style={{ marginBottom: 8 }}>
                  {selectedPaper.publicationVenue} ({selectedPaper.publicationYear})
                </span>
                <h2 style={{ fontSize: '1.3rem', fontWeight: 700, color: '#F8FAFC' }}>
                  {selectedPaper.title}
                </h2>
                <p style={{ fontSize: '0.85rem', color: '#94A3B8', marginTop: 4 }}>
                  {selectedPaper.authors}
                </p>
              </div>
              <button
                onClick={() => setSelectedPaper(null)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--text-muted)',
                  fontSize: '1.5rem',
                  cursor: 'pointer'
                }}
              >
                &times;
              </button>
            </div>

            <div style={{ marginBottom: 20 }}>
              <h4 style={{ fontSize: '0.9rem', color: '#38BDF8', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Abstract
              </h4>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.7, whiteSpace: 'pre-line' }}>
                {selectedPaper.abstractText}
              </p>
            </div>

            {selectedPaper.methodology && (
              <div style={{ marginBottom: 20 }}>
                <h4 style={{ fontSize: '0.9rem', color: '#8B5CF6', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Core Methodology & Algorithm
                </h4>
                <div style={{
                  padding: 14,
                  borderRadius: 8,
                  backgroundColor: 'rgba(139, 92, 246, 0.08)',
                  border: '1px solid rgba(139, 92, 246, 0.25)',
                  fontSize: '0.84rem',
                  color: '#DDD6FE',
                  lineHeight: 1.6
                }}>
                  {selectedPaper.methodology}
                </div>
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 24 }}>
              <button className="btn-secondary" onClick={() => setSelectedPaper(null)}>
                Close
              </button>
              <button 
                className="btn-primary" 
                onClick={() => {
                  onCreateTaskFromPaper(selectedPaper);
                  setSelectedPaper(null);
                }}
              >
                <PlusCircle size={15} />
                <span>Create Pipeline Task</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
