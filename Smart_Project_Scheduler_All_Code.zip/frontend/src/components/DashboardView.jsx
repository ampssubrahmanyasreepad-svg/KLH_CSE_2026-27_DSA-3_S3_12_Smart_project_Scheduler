import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Layers, 
  GitCommit, 
  AlertCircle, 
  Flame, 
  Zap, 
  TrendingUp,
  ArrowRight,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';

export default function DashboardView({ 
  stats, 
  tasks, 
  papers, 
  deadlockActive, 
  onNavigateTab 
}) {
  if (!stats) {
    return (
      <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
        Loading dashboard metrics...
      </div>
    );
  }

  // Priority chart data
  const priorityData = stats.priorityDistribution ? Object.entries(stats.priorityDistribution).map(([name, value]) => ({
    name,
    value,
  })) : [];

  const PRIORITY_COLORS = {
    CRITICAL: '#F43F5E',
    HIGH: '#F59E0B',
    MEDIUM: '#38BDF8',
    LOW: '#10B981',
  };

  // Status chart data
  const statusData = stats.statusDistribution ? Object.entries(stats.statusDistribution).map(([name, count]) => ({
    status: name.replace('_', ' '),
    count,
  })) : [];

  return (
    <div style={{ padding: '24px 20px', maxWidth: 1400, margin: '0 auto' }}>
      {/* Top Banner if Deadlock Detected */}
      {(!stats.dagValid || deadlockActive) && (
        <div style={{
          backgroundColor: 'rgba(244, 63, 94, 0.12)',
          border: '1px solid rgba(244, 63, 94, 0.4)',
          borderRadius: 12,
          padding: '16px 20px',
          marginBottom: 24,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          animation: 'pulseGlow 2s infinite'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{
              width: 40,
              height: 40,
              borderRadius: 8,
              backgroundColor: 'rgba(244, 63, 94, 0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <AlertTriangle size={22} color="#FB7185" />
            </div>
            <div>
              <h4 style={{ margin: 0, color: '#FDA4AF', fontSize: '1rem', fontWeight: 600 }}>
                Circular Dependency Deadlock Detected (Kahn's Algorithm Flagged)
              </h4>
              <p style={{ margin: '2px 0 0', color: 'var(--text-secondary)', fontSize: '0.82rem' }}>
                A cyclical prerequisite loop exists ($A \rightarrow B \rightarrow A$), preventing linear topological execution.
              </p>
            </div>
          </div>
          <button 
            className="btn-danger"
            onClick={() => onNavigateTab('algorithms')}
            style={{ fontSize: '0.8rem' }}
          >
            Inspect in Algorithmic Engine &rarr;
          </button>
        </div>
      )}

      {/* KPI Metric Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
        gap: 16,
        marginBottom: 24,
      }}>
        {/* Card 1: Total Tasks & Completion */}
        <div className="glass-card" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Execution Tasks
            </span>
            <div style={{ padding: 6, borderRadius: 8, backgroundColor: 'rgba(56, 189, 248, 0.12)' }}>
              <Layers size={18} color="#38BDF8" />
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 12 }}>
            <span style={{ fontSize: '2rem', fontWeight: 800, color: '#F8FAFC' }}>
              {stats.totalTasks}
            </span>
            <span className="badge badge-emerald" style={{ fontSize: '0.75rem' }}>
              {stats.completionRate}% Done
            </span>
          </div>
          <div style={{ marginTop: 12, backgroundColor: 'rgba(255, 255, 255, 0.06)', borderRadius: 4, height: 6, overflow: 'hidden' }}>
            <div style={{
              width: `${stats.completionRate}%`,
              height: '100%',
              background: 'linear-gradient(90deg, #0284C7, #10B981)',
              borderRadius: 4,
              transition: 'width 0.6s ease'
            }} />
          </div>
        </div>

        {/* Card 2: Research Papers */}
        <div className="glass-card" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Research Catalog
            </span>
            <div style={{ padding: 6, borderRadius: 8, backgroundColor: 'rgba(139, 92, 246, 0.12)' }}>
              <Zap size={18} color="#A78BFA" />
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 12 }}>
            <span style={{ fontSize: '2rem', fontWeight: 800, color: '#F8FAFC' }}>
              {stats.totalPapers}
            </span>
            <span className="badge badge-purple" style={{ fontSize: '0.72rem' }}>
              Rabin-Karp Indexed
            </span>
          </div>
          <p style={{ marginTop: 8, fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Deep Learning & Systems Papers
          </p>
        </div>

        {/* Card 3: Graph Topology (Vertices & Edges) */}
        <div className="glass-card" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Graph Topology
            </span>
            <div style={{ padding: 6, borderRadius: 8, backgroundColor: 'rgba(16, 185, 129, 0.12)' }}>
              <GitCommit size={18} color="#34D399" />
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 12 }}>
            <span style={{ fontSize: '2rem', fontWeight: 800, color: '#F8FAFC' }}>
              {stats.graphVertexCount}V / {stats.graphEdgeCount}E
            </span>
            <span className={stats.dagValid ? 'badge badge-emerald' : 'badge badge-rose'}>
              {stats.dagValid ? 'DAG Valid' : 'Deadlocked'}
            </span>
          </div>
          <p style={{ marginTop: 8, fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            O(V + E) Kahn's Pipeline
          </p>
        </div>

        {/* Card 4: Critical Path Duration */}
        <div className="glass-card" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Critical Path (CPM)
            </span>
            <div style={{ padding: 6, borderRadius: 8, backgroundColor: 'rgba(245, 158, 11, 0.12)' }}>
              <Clock size={18} color="#FBBF24" />
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 12 }}>
            <span style={{ fontSize: '2rem', fontWeight: 800, color: '#F8FAFC' }}>
              {stats.criticalPathHours} hrs
            </span>
            <span className="badge badge-amber" style={{ fontSize: '0.75rem' }}>
              Longest Path
            </span>
          </div>
          <p style={{ marginTop: 8, fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Dynamic Programming over DAG
          </p>
        </div>
      </div>

      {/* Main Charts & Analytics Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))',
        gap: 20,
        marginBottom: 24,
      }}>
        {/* Chart 1: Priority Distribution Donut */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#F8FAFC' }}>
              Priority Breakdown (Min-Heap Weights)
            </h3>
            <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
              Scheduler Heuristic
            </span>
          </div>

          <div style={{ height: 240, display: 'flex', alignItems: 'center' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={priorityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {priorityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PRIORITY_COLORS[entry.name] || '#38BDF8'} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1E293B', border: '1px solid rgba(56, 189, 248, 0.3)', borderRadius: 8 }}
                  itemStyle={{ color: '#F8FAFC' }}
                />
                <Legend 
                  verticalAlign="bottom" 
                  height={36} 
                  formatter={(val) => <span style={{ color: '#94A3B8', fontSize: '0.8rem' }}>{val}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Task Status Distribution */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#F8FAFC' }}>
              Execution Lifecycle Status
            </h3>
            <span className="badge badge-emerald" style={{ fontSize: '0.7rem' }}>
              Lifecycle State
            </span>
          </div>

          <div style={{ height: 240 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="status" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1E293B', border: '1px solid rgba(56, 189, 248, 0.3)', borderRadius: 8 }}
                  itemStyle={{ color: '#F8FAFC' }}
                />
                <Bar dataKey="count" fill="#38BDF8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Section: Active Tasks & Quick Jump */}
      <div className="glass-panel" style={{ padding: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#F8FAFC' }}>
              Active Pipeline Tasks
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', margin: '2px 0 0' }}>
              Tasks integrated from research papers and scheduled on the execution graph
            </p>
          </div>
          <button 
            className="btn-primary"
            onClick={() => onNavigateTab('dag')}
            style={{ fontSize: '0.8rem' }}
          >
            Launch Interactive DAG Visualizer &rarr;
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 12 }}>
          {tasks.slice(0, 6).map((task) => (
            <div 
              key={task.id}
              className="glass-card"
              style={{
                padding: 14,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                borderLeft: `4px solid ${task.colorTag || '#38BDF8'}`
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span className="font-mono" style={{ fontSize: '0.8rem', fontWeight: 600, color: '#38BDF8' }}>
                    {task.taskKey}
                  </span>
                  <span className={`badge ${
                    task.priority === 'CRITICAL' ? 'badge-rose' :
                    task.priority === 'HIGH' ? 'badge-amber' :
                    task.priority === 'MEDIUM' ? 'badge-cyan' : 'badge-emerald'
                  }`} style={{ fontSize: '0.65rem' }}>
                    {task.priority}
                  </span>
                </div>
                <h4 style={{ fontSize: '0.88rem', fontWeight: 600, color: '#F8FAFC', marginBottom: 4 }}>
                  {task.title}
                </h4>
                <p style={{ 
                  fontSize: '0.75rem', 
                  color: 'var(--text-muted)', 
                  display: '-webkit-box', 
                  WebkitLineClamp: 2, 
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden' 
                }}>
                  {task.description}
                </p>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 8, borderTop: '1px solid rgba(255, 255, 255, 0.05)' }}>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>
                  Duration: <strong style={{ color: '#F8FAFC' }}>{task.estimatedDurationHours}h</strong>
                </span>
                <span className={`badge ${
                  task.status === 'COMPLETED' ? 'badge-emerald' :
                  task.status === 'IN_PROGRESS' ? 'badge-purple' :
                  task.status === 'READY' ? 'badge-cyan' : 'badge-amber'
                }`} style={{ fontSize: '0.65rem' }}>
                  {task.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
