package com.nexusplan.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "tasks")
public class TaskItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 32)
    private String taskKey; // e.g. "TASK-01"

    @Column(nullable = false, length = 256)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private String status = "READY"; // PENDING, READY, IN_PROGRESS, COMPLETED, BLOCKED

    @Column(nullable = false)
    private String priority = "MEDIUM"; // CRITICAL, HIGH, MEDIUM, LOW

    private Integer estimatedDurationHours = 8;

    private LocalDate deadline;

    private Long paperId;

    private String paperTitle;

    private String colorTag = "#38BDF8";

    private Double positionX = 100.0;
    private Double positionY = 100.0;

    private LocalDateTime createdAt = LocalDateTime.now();

    public TaskItem() {}

    public TaskItem(String taskKey, String title, String description, String status, String priority,
                    Integer estimatedDurationHours, LocalDate deadline, Long paperId, String paperTitle,
                    String colorTag, Double positionX, Double positionY) {
        this.taskKey = taskKey;
        this.title = title;
        this.description = description;
        this.status = status;
        this.priority = priority;
        this.estimatedDurationHours = estimatedDurationHours;
        this.deadline = deadline;
        this.paperId = paperId;
        this.paperTitle = paperTitle;
        this.colorTag = colorTag;
        this.positionX = positionX;
        this.positionY = positionY;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTaskKey() { return taskKey; }
    public void setTaskKey(String taskKey) { this.taskKey = taskKey; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public Integer getEstimatedDurationHours() { return estimatedDurationHours; }
    public void setEstimatedDurationHours(Integer estimatedDurationHours) { this.estimatedDurationHours = estimatedDurationHours; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public Long getPaperId() { return paperId; }
    public void setPaperId(Long paperId) { this.paperId = paperId; }

    public String getPaperTitle() { return paperTitle; }
    public void setPaperTitle(String paperTitle) { this.paperTitle = paperTitle; }

    public String getColorTag() { return colorTag; }
    public void setColorTag(String colorTag) { this.colorTag = colorTag; }

    public Double getPositionX() { return positionX; }
    public void setPositionX(Double positionX) { this.positionX = positionX; }

    public Double getPositionY() { return positionY; }
    public void setPositionY(Double positionY) { this.positionY = positionY; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
