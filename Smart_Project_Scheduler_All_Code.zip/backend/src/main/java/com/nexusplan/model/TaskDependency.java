package com.nexusplan.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "task_dependencies", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"source_task_id", "target_task_id"})
})
public class TaskDependency {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "source_task_id", nullable = false)
    private Long sourceTaskId; // Prerequisite task

    @Column(name = "target_task_id", nullable = false)
    private Long targetTaskId; // Dependent task

    private String dependencyType = "HARD"; // HARD (blocking), SOFT (recommended)

    private String label;

    private LocalDateTime createdAt = LocalDateTime.now();

    public TaskDependency() {}

    public TaskDependency(Long sourceTaskId, Long targetTaskId, String dependencyType, String label) {
        this.sourceTaskId = sourceTaskId;
        this.targetTaskId = targetTaskId;
        this.dependencyType = dependencyType;
        this.label = label;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSourceTaskId() { return sourceTaskId; }
    public void setSourceTaskId(Long sourceTaskId) { this.sourceTaskId = sourceTaskId; }

    public Long getTargetTaskId() { return targetTaskId; }
    public void setTargetTaskId(Long targetTaskId) { this.targetTaskId = targetTaskId; }

    public String getDependencyType() { return dependencyType; }
    public void setDependencyType(String dependencyType) { this.dependencyType = dependencyType; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
