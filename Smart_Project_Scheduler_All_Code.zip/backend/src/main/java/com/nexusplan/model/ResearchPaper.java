package com.nexusplan.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "research_papers")
public class ResearchPaper {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 512)
    private String title;

    @Column(nullable = false, length = 512)
    private String authors;

    private Integer publicationYear;

    private String publicationVenue;

    @Column(columnDefinition = "TEXT")
    private String abstractText;

    @Column(columnDefinition = "TEXT")
    private String methodology;

    private String arxivUrl;

    private String tags; // Comma-separated: "Transformer, Attention, Deep Learning"

    private LocalDateTime createdAt = LocalDateTime.now();

    public ResearchPaper() {}

    public ResearchPaper(String title, String authors, Integer publicationYear, String publicationVenue,
                         String abstractText, String methodology, String arxivUrl, String tags) {
        this.title = title;
        this.authors = authors;
        this.publicationYear = publicationYear;
        this.publicationVenue = publicationVenue;
        this.abstractText = abstractText;
        this.methodology = methodology;
        this.arxivUrl = arxivUrl;
        this.tags = tags;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthors() { return authors; }
    public void setAuthors(String authors) { this.authors = authors; }

    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }

    public String getPublicationVenue() { return publicationVenue; }
    public void setPublicationVenue(String publicationVenue) { this.publicationVenue = publicationVenue; }

    public String getAbstractText() { return abstractText; }
    public void setAbstractText(String abstractText) { this.abstractText = abstractText; }

    public String getMethodology() { return methodology; }
    public void setMethodology(String methodology) { this.methodology = methodology; }

    public String getArxivUrl() { return arxivUrl; }
    public void setArxivUrl(String arxivUrl) { this.arxivUrl = arxivUrl; }

    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
