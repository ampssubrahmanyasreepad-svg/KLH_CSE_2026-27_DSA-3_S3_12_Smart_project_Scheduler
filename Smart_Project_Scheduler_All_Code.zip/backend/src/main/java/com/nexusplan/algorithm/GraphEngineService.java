package com.nexusplan.algorithm;

import com.nexusplan.dto.*;
import com.nexusplan.model.TaskDependency;
import com.nexusplan.model.TaskItem;
import com.nexusplan.repository.TaskDependencyRepository;
import com.nexusplan.repository.TaskItemRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class GraphEngineService {

    private final TaskItemRepository taskRepository;
    private final TaskDependencyRepository dependencyRepository;

    public GraphEngineService(TaskItemRepository taskRepository, TaskDependencyRepository dependencyRepository) {
        this.taskRepository = taskRepository;
        this.dependencyRepository = dependencyRepository;
    }

    /**
     * Breadth-First Search (BFS) Traversal with detailed step-by-step logs for interactive graph playback.
     */
    public BfsResult runBfs(Long startTaskId) {
        long startTime = System.nanoTime();
        List<TaskItem> allTasks = taskRepository.findAll();
        List<TaskDependency> allEdges = dependencyRepository.findAll();

        Map<Long, TaskItem> taskMap = allTasks.stream().collect(Collectors.toMap(TaskItem::getId, t -> t));
        Map<Long, List<Long>> adj = new HashMap<>();
        for (TaskItem t : allTasks) {
            adj.put(t.getId(), new ArrayList<>());
        }
        for (TaskDependency edge : allEdges) {
            if (adj.containsKey(edge.getSourceTaskId())) {
                adj.get(edge.getSourceTaskId()).add(edge.getTargetTaskId());
            }
        }

        // Determine start node
        Long actualStartId = startTaskId;
        if (actualStartId == null || !taskMap.containsKey(actualStartId)) {
            // Find a source node with in-degree = 0, or first task
            Set<Long> targets = allEdges.stream().map(TaskDependency::getTargetTaskId).collect(Collectors.toSet());
            actualStartId = allTasks.stream()
                    .map(TaskItem::getId)
                    .filter(id -> !targets.contains(id))
                    .findFirst()
                    .orElse(!allTasks.isEmpty() ? allTasks.get(0).getId() : null);
        }

        BfsResult result = new BfsResult();
        if (actualStartId == null) {
            return result;
        }

        result.setStartTaskId(actualStartId);
        result.setStartTaskKey(taskMap.get(actualStartId).getTaskKey());

        Queue<Long> queue = new LinkedList<>();
        Set<Long> visited = new HashSet<>();
        Map<String, Integer> levelMap = new HashMap<>();
        List<BfsResult.BfsStep> steps = new ArrayList<>();
        List<String> traversalOrder = new ArrayList<>();

        queue.add(actualStartId);
        visited.add(actualStartId);
        levelMap.put(taskMap.get(actualStartId).getTaskKey(), 0);

        int stepNum = 1;
        steps.add(new BfsResult.BfsStep(
                stepNum++,
                taskMap.get(actualStartId).getTaskKey(),
                queue.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                visited.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                Collections.singletonList(taskMap.get(actualStartId).getTaskKey()),
                "Enqueued root origin task " + taskMap.get(actualStartId).getTaskKey() + " at BFS Level 0"
        ));

        while (!queue.isEmpty()) {
            Long currentId = queue.poll();
            TaskItem currentTask = taskMap.get(currentId);
            traversalOrder.add(currentTask.getTaskKey());
            int currentLevel = levelMap.getOrDefault(currentTask.getTaskKey(), 0);

            List<String> frontier = new ArrayList<>();
            List<Long> neighbors = adj.getOrDefault(currentId, Collections.emptyList());
            for (Long neighborId : neighbors) {
                if (!visited.contains(neighborId) && taskMap.containsKey(neighborId)) {
                    visited.add(neighborId);
                    queue.add(neighborId);
                    levelMap.put(taskMap.get(neighborId).getTaskKey(), currentLevel + 1);
                    frontier.add(taskMap.get(neighborId).getTaskKey());
                }
            }

            steps.add(new BfsResult.BfsStep(
                    stepNum++,
                    currentTask.getTaskKey(),
                    queue.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                    visited.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                    frontier,
                    "Visited node " + currentTask.getTaskKey() + " (Level " + currentLevel + "). Discovered downstream frontier: "
                            + (frontier.isEmpty() ? "[None]" : String.join(", ", frontier))
            ));
        }

        result.setSteps(steps);
        result.setTraversalOrder(traversalOrder);
        result.setLevelMap(levelMap);
        result.setExecutionTimeMicros((System.nanoTime() - startTime) / 1000);
        return result;
    }

    /**
     * Depth-First Search (DFS) Traversal with recursion call-stack tracking and edge classification.
     */
    public DfsResult runDfs(Long startTaskId) {
        long startTime = System.nanoTime();
        List<TaskItem> allTasks = taskRepository.findAll();
        List<TaskDependency> allEdges = dependencyRepository.findAll();

        Map<Long, TaskItem> taskMap = allTasks.stream().collect(Collectors.toMap(TaskItem::getId, t -> t));
        Map<Long, List<Long>> adj = new HashMap<>();
        for (TaskItem t : allTasks) {
            adj.put(t.getId(), new ArrayList<>());
        }
        for (TaskDependency edge : allEdges) {
            if (adj.containsKey(edge.getSourceTaskId())) {
                adj.get(edge.getSourceTaskId()).add(edge.getTargetTaskId());
            }
        }

        Long actualStartId = startTaskId;
        if (actualStartId == null || !taskMap.containsKey(actualStartId)) {
            Set<Long> targets = allEdges.stream().map(TaskDependency::getTargetTaskId).collect(Collectors.toSet());
            actualStartId = allTasks.stream()
                    .map(TaskItem::getId)
                    .filter(id -> !targets.contains(id))
                    .findFirst()
                    .orElse(!allTasks.isEmpty() ? allTasks.get(0).getId() : null);
        }

        DfsResult result = new DfsResult();
        if (actualStartId == null) {
            return result;
        }

        result.setStartTaskId(actualStartId);
        result.setStartTaskKey(taskMap.get(actualStartId).getTaskKey());

        Set<Long> visited = new HashSet<>();
        Set<Long> onStack = new HashSet<>();
        List<String> callStack = new ArrayList<>();
        List<DfsResult.DfsStep> steps = new ArrayList<>();
        List<String> traversalOrder = new ArrayList<>();
        Map<String, Integer> discoveryTimes = new HashMap<>();
        Map<String, Integer> finishTimes = new HashMap<>();
        List<String> backEdges = new ArrayList<>();
        int[] timer = new int[]{1};
        int[] stepNum = new int[]{1};

        dfsRecursive(actualStartId, adj, taskMap, visited, onStack, callStack, steps,
                traversalOrder, discoveryTimes, finishTimes, backEdges, timer, stepNum);

        result.setSteps(steps);
        result.setTraversalOrder(traversalOrder);
        result.setDiscoveryTimes(discoveryTimes);
        result.setFinishTimes(finishTimes);
        result.setBackEdges(backEdges);
        result.setExecutionTimeMicros((System.nanoTime() - startTime) / 1000);
        return result;
    }

    private void dfsRecursive(Long u, Map<Long, List<Long>> adj, Map<Long, TaskItem> taskMap,
                              Set<Long> visited, Set<Long> onStack, List<String> callStack,
                              List<DfsResult.DfsStep> steps, List<String> traversalOrder,
                              Map<String, Integer> discoveryTimes, Map<String, Integer> finishTimes,
                              List<String> backEdges, int[] timer, int[] stepNum) {
        TaskItem uTask = taskMap.get(u);
        String uKey = uTask.getTaskKey();

        visited.add(u);
        onStack.add(u);
        callStack.add(uKey);
        traversalOrder.add(uKey);
        discoveryTimes.put(uKey, timer[0]++);

        steps.add(new DfsResult.DfsStep(
                stepNum[0]++,
                uKey,
                new ArrayList<>(callStack),
                visited.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                "TREE_NODE_DISCOVERY",
                "Discovered node " + uKey + " (Time d=" + discoveryTimes.get(uKey) + "). Pushed to call stack."
        ));

        for (Long v : adj.getOrDefault(u, Collections.emptyList())) {
            if (!taskMap.containsKey(v)) continue;
            String vKey = taskMap.get(v).getTaskKey();

            if (onStack.contains(v)) {
                // Back-edge detected! This indicates a cycle/deadlock
                String backEdgeDesc = uKey + " -> " + vKey;
                backEdges.add(backEdgeDesc);
                steps.add(new DfsResult.DfsStep(
                        stepNum[0]++,
                        uKey,
                        new ArrayList<>(callStack),
                        visited.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                        "BACK_EDGE_CYCLE",
                        "CRITICAL: Back-edge detected from " + uKey + " to ancestor " + vKey + " (Circular Deadlock)!"
                ));
            } else if (!visited.contains(v)) {
                dfsRecursive(v, adj, taskMap, visited, onStack, callStack, steps,
                        traversalOrder, discoveryTimes, finishTimes, backEdges, timer, stepNum);
            }
        }

        onStack.remove(u);
        callStack.remove(callStack.size() - 1);
        finishTimes.put(uKey, timer[0]++);

        steps.add(new DfsResult.DfsStep(
                stepNum[0]++,
                uKey,
                new ArrayList<>(callStack),
                visited.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                "POP_FINISH",
                "Finished subtree for " + uKey + " (Time f=" + finishTimes.get(uKey) + "). Popped from call stack."
        ));
    }

    /**
     * Deterministic Pipeline Ordering: Kahn's Algorithm for Topological Sorting
     * and Circular Dependency Deadlock Detection (A -> B -> A).
     */
    public TopologicalSortResult runTopologicalSort() {
        long startTime = System.nanoTime();
        List<TaskItem> allTasks = taskRepository.findAll();
        List<TaskDependency> allEdges = dependencyRepository.findAll();

        Map<Long, TaskItem> taskMap = allTasks.stream().collect(Collectors.toMap(TaskItem::getId, t -> t));
        Map<Long, List<Long>> adj = new HashMap<>();
        Map<Long, Integer> inDegree = new HashMap<>();

        for (TaskItem t : allTasks) {
            adj.put(t.getId(), new ArrayList<>());
            inDegree.put(t.getId(), 0);
        }

        for (TaskDependency edge : allEdges) {
            if (adj.containsKey(edge.getSourceTaskId()) && inDegree.containsKey(edge.getTargetTaskId())) {
                adj.get(edge.getSourceTaskId()).add(edge.getTargetTaskId());
                inDegree.put(edge.getTargetTaskId(), inDegree.get(edge.getTargetTaskId()) + 1);
            }
        }

        TopologicalSortResult result = new TopologicalSortResult();
        Map<String, Integer> initialInDegrees = new HashMap<>();
        for (Map.Entry<Long, Integer> entry : inDegree.entrySet()) {
            if (taskMap.containsKey(entry.getKey())) {
                initialInDegrees.put(taskMap.get(entry.getKey()).getTaskKey(), entry.getValue());
            }
        }
        result.setInitialInDegrees(initialInDegrees);

        // Kahn's Algorithm: initialize queue with nodes having in-degree 0
        Queue<Long> queue = new LinkedList<>();
        for (TaskItem t : allTasks) {
            if (inDegree.get(t.getId()) == 0) {
                queue.add(t.getId());
            }
        }

        List<TaskItem> pipeline = new ArrayList<>();
        List<String> pipelineKeys = new ArrayList<>();
        List<TopologicalSortResult.TopologicalStep> steps = new ArrayList<>();
        int stepNum = 1;

        Map<String, Integer> currentDegreesMap = new HashMap<>(initialInDegrees);
        steps.add(new TopologicalSortResult.TopologicalStep(
                stepNum++,
                "INITIALIZATION",
                queue.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                new HashMap<>(currentDegreesMap),
                new ArrayList<>(pipelineKeys),
                "Initialized Kahn's Algorithm. Found " + queue.size() + " tasks with zero in-degree prerequisites."
        ));

        while (!queue.isEmpty()) {
            Long uId = queue.poll();
            TaskItem uTask = taskMap.get(uId);
            pipeline.add(uTask);
            pipelineKeys.add(uTask.getTaskKey());

            List<Long> downstream = adj.getOrDefault(uId, Collections.emptyList());
            for (Long vId : downstream) {
                int deg = inDegree.get(vId) - 1;
                inDegree.put(vId, deg);
                currentDegreesMap.put(taskMap.get(vId).getTaskKey(), deg);

                if (deg == 0) {
                    queue.add(vId);
                }
            }

            steps.add(new TopologicalSortResult.TopologicalStep(
                    stepNum++,
                    uTask.getTaskKey(),
                    queue.stream().map(id -> taskMap.get(id).getTaskKey()).collect(Collectors.toList()),
                    new HashMap<>(currentDegreesMap),
                    new ArrayList<>(pipelineKeys),
                    "Dispatched " + uTask.getTaskKey() + ". Decremented prerequisite requirements on "
                            + downstream.size() + " dependent downstream nodes."
            ));
        }

        result.setSteps(steps);
        result.setExecutionPipeline(pipeline);
        result.setExecutionOrderKeys(pipelineKeys);

        // Circular Dependency Deadlock Detection:
        // If total processed vertices < total vertices, a cycle exists
        if (pipeline.size() < allTasks.size()) {
            result.setHasCycle(true);
            result.setDeadlockDetected(true);

            // Identify deadlock members: tasks with inDegree > 0
            List<String> deadlockTasks = new ArrayList<>();
            for (TaskItem t : allTasks) {
                if (inDegree.get(t.getId()) > 0) {
                    deadlockTasks.add(t.getTaskKey());
                }
            }
            result.setCycleNodes(deadlockTasks);

            // Find specific cycle edge descriptions
            List<String> cycleEdges = new ArrayList<>();
            for (TaskDependency edge : allEdges) {
                if (deadlockTasks.contains(taskMap.get(edge.getSourceTaskId()).getTaskKey())
                        && deadlockTasks.contains(taskMap.get(edge.getTargetTaskId()).getTaskKey())) {
                    cycleEdges.add(taskMap.get(edge.getSourceTaskId()).getTaskKey() + " ➔ " + taskMap.get(edge.getTargetTaskId()).getTaskKey());
                }
            }
            result.setCycleEdgeDescriptions(cycleEdges);

            result.setDiagnosticMessage("DEADLOCK DETECTED: Circular dependency cycle present ("
                    + String.join(" ➔ ", deadlockTasks) + "). Kahn's Algorithm could only order "
                    + pipeline.size() + " of " + allTasks.size() + " tasks before mutual dependency starvation.");
        } else {
            result.setHasCycle(false);
            result.setDeadlockDetected(false);
            result.setDiagnosticMessage("SUCCESS: Valid Directed Acyclic Graph (DAG) verified. All "
                    + pipeline.size() + " tasks have a deterministic, acyclic linear topological execution order.");
        }

        result.setExecutionTimeMicros((System.nanoTime() - startTime) / 1000);
        return result;
    }

    /**
     * Adaptive Task Dispatcher: Min-Heap / Priority Queue Multi-Worker Scheduling
     * Prioritizes tasks by:
     * 1. Priority Weight: CRITICAL (4) > HIGH (3) > MEDIUM (2) > LOW (1)
     * 2. Estimated Duration (Shortest Job First tiebreaker)
     * 3. Earliest Deadline
     */
    public DispatchScheduleResult runTaskDispatcher(int workerCount) {
        long startTime = System.nanoTime();
        if (workerCount <= 0) workerCount = 3;

        List<TaskItem> allTasks = taskRepository.findAll();
        List<TaskDependency> allEdges = dependencyRepository.findAll();
        Map<Long, TaskItem> taskMap = allTasks.stream().collect(Collectors.toMap(TaskItem::getId, t -> t));

        // Dependency counts
        Map<Long, Integer> inDegree = new HashMap<>();
        Map<Long, List<Long>> adj = new HashMap<>();
        for (TaskItem t : allTasks) {
            inDegree.put(t.getId(), 0);
            adj.put(t.getId(), new ArrayList<>());
        }
        for (TaskDependency edge : allEdges) {
            if (adj.containsKey(edge.getSourceTaskId()) && inDegree.containsKey(edge.getTargetTaskId())) {
                adj.get(edge.getSourceTaskId()).add(edge.getTargetTaskId());
                inDegree.put(edge.getTargetTaskId(), inDegree.get(edge.getTargetTaskId()) + 1);
            }
        }

        // Custom Comparator for Priority Queue (Min-Heap on Cost / Max on Priority)
        Comparator<TaskItem> taskComparator = (a, b) -> {
            int pA = getPriorityWeight(a.getPriority());
            int pB = getPriorityWeight(b.getPriority());
            if (pA != pB) {
                return Integer.compare(pB, pA); // Higher priority first
            }
            // Tie-break: shorter duration first
            int durCompare = Integer.compare(
                    a.getEstimatedDurationHours() != null ? a.getEstimatedDurationHours() : 8,
                    b.getEstimatedDurationHours() != null ? b.getEstimatedDurationHours() : 8
            );
            if (durCompare != 0) return durCompare;
            return a.getTaskKey().compareTo(b.getTaskKey());
        };

        PriorityQueue<TaskItem> readyHeap = new PriorityQueue<>(taskComparator);
        List<DispatchScheduleResult.HeapEventLog> heapLogs = new ArrayList<>();

        for (TaskItem t : allTasks) {
            if (inDegree.get(t.getId()) == 0) {
                readyHeap.offer(t);
                heapLogs.add(new DispatchScheduleResult.HeapEventLog(
                        "INSERT_MIN_HEAP",
                        t.getTaskKey(),
                        "Task " + t.getTaskKey() + " [Priority=" + t.getPriority() + "] added to Ready Heap",
                        readyHeap.stream().map(TaskItem::getTaskKey).collect(Collectors.toList())
                ));
            }
        }

        // Multi-worker timeline simulation
        String[] workerNames = {"Worker-Alpha (Core-1)", "Worker-Beta (Core-2)", "Worker-Gamma (Core-3)", "Worker-Delta (Core-4)"};
        int[] workerNextAvailable = new int[workerCount];
        Map<String, Integer> workerWorkloads = new HashMap<>();
        for (int i = 0; i < workerCount; i++) {
            workerWorkloads.put(workerNames[i % workerNames.length], 0);
        }

        List<DispatchScheduleResult.ScheduledTaskSlot> slots = new ArrayList<>();
        Map<Long, Integer> taskFinishTimes = new HashMap<>();

        while (!readyHeap.isEmpty()) {
            TaskItem chosen = readyHeap.poll();
            heapLogs.add(new DispatchScheduleResult.HeapEventLog(
                    "EXTRACT_MIN",
                    chosen.getTaskKey(),
                    "Dispatched optimal task " + chosen.getTaskKey() + " to worker pool",
                    readyHeap.stream().map(TaskItem::getTaskKey).collect(Collectors.toList())
            ));

            // Find worker with earliest available time
            int bestWorkerIdx = 0;
            for (int i = 1; i < workerCount; i++) {
                if (workerNextAvailable[i] < workerNextAvailable[bestWorkerIdx]) {
                    bestWorkerIdx = i;
                }
            }

            int dur = chosen.getEstimatedDurationHours() != null ? chosen.getEstimatedDurationHours() : 4;
            int startHour = workerNextAvailable[bestWorkerIdx];
            int endHour = startHour + dur;
            workerNextAvailable[bestWorkerIdx] = endHour;
            taskFinishTimes.put(chosen.getId(), endHour);

            String workerName = workerNames[bestWorkerIdx % workerNames.length];
            workerWorkloads.put(workerName, workerWorkloads.get(workerName) + dur);

            slots.add(new DispatchScheduleResult.ScheduledTaskSlot(
                    chosen.getTaskKey(),
                    chosen.getTitle(),
                    chosen.getPriority(),
                    dur,
                    workerName,
                    startHour,
                    endHour,
                    getPriorityWeight(chosen.getPriority()) * 10.0 - dur,
                    readyHeap.stream().map(TaskItem::getTaskKey).collect(Collectors.toList())
            ));

            // Decrement downstream in-degrees & add new ready tasks to heap
            for (Long dependentId : adj.getOrDefault(chosen.getId(), Collections.emptyList())) {
                int deg = inDegree.get(dependentId) - 1;
                inDegree.put(dependentId, deg);
                if (deg == 0) {
                    TaskItem dependentTask = taskMap.get(dependentId);
                    readyHeap.offer(dependentTask);
                    heapLogs.add(new DispatchScheduleResult.HeapEventLog(
                            "HEAPIFY_UP",
                            dependentTask.getTaskKey(),
                            "Prerequisites fulfilled: " + dependentTask.getTaskKey() + " pushed and heapified into Ready Queue",
                            readyHeap.stream().map(TaskItem::getTaskKey).collect(Collectors.toList())
                    ));
                }
            }
        }

        int maxDuration = 0;
        for (int avail : workerNextAvailable) {
            if (avail > maxDuration) maxDuration = avail;
        }

        DispatchScheduleResult result = new DispatchScheduleResult();
        result.setScheduleSlots(slots);
        result.setTotalPipelineDurationHours(maxDuration);
        result.setActiveWorkerCount(workerCount);
        result.setWorkerWorkloadsHours(workerWorkloads);
        result.setHeapOperations(heapLogs);
        result.setExecutionTimeMicros((System.nanoTime() - startTime) / 1000);
        return result;
    }

    private int getPriorityWeight(String priority) {
        if (priority == null) return 2;
        return switch (priority.toUpperCase()) {
            case "CRITICAL" -> 4;
            case "HIGH" -> 3;
            case "MEDIUM" -> 2;
            case "LOW" -> 1;
            default -> 2;
        };
    }

    /**
     * Graph Diagnostics (Algorithm Lab): Complexity analytics, Density, Critical Path Length,
     * and Code Inspector code snippets.
     */
    public GraphDiagnosticsDTO getDiagnostics() {
        List<TaskItem> allTasks = taskRepository.findAll();
        List<TaskDependency> allEdges = dependencyRepository.findAll();

        int v = allTasks.size();
        int e = allEdges.size();

        double density = (v > 1) ? ((double) e / (v * (v - 1))) : 0.0;

        Map<Long, Integer> inDegrees = new HashMap<>();
        Map<Long, Integer> outDegrees = new HashMap<>();
        for (TaskItem t : allTasks) {
            inDegrees.put(t.getId(), 0);
            outDegrees.put(t.getId(), 0);
        }
        for (TaskDependency edge : allEdges) {
            if (outDegrees.containsKey(edge.getSourceTaskId())) {
                outDegrees.put(edge.getSourceTaskId(), outDegrees.get(edge.getSourceTaskId()) + 1);
            }
            if (inDegrees.containsKey(edge.getTargetTaskId())) {
                inDegrees.put(edge.getTargetTaskId(), inDegrees.get(edge.getTargetTaskId()) + 1);
            }
        }

        int maxIn = inDegrees.values().stream().max(Integer::compare).orElse(0);
        int maxOut = outDegrees.values().stream().max(Integer::compare).orElse(0);

        // Check acyclic status and calculate Critical Path
        TopologicalSortResult topo = runTopologicalSort();
        int criticalPathHours = 0;
        if (!topo.isHasCycle()) {
            // CPM Dynamic Programming: dist[v] = max(dist[u] + duration[v])
            Map<Long, Integer> dist = new HashMap<>();
            Map<Long, List<Long>> adj = new HashMap<>();
            for (TaskItem t : allTasks) {
                dist.put(t.getId(), t.getEstimatedDurationHours() != null ? t.getEstimatedDurationHours() : 8);
                adj.put(t.getId(), new ArrayList<>());
            }
            for (TaskDependency edge : allEdges) {
                if (adj.containsKey(edge.getSourceTaskId())) {
                    adj.get(edge.getSourceTaskId()).add(edge.getTargetTaskId());
                }
            }

            for (TaskItem u : topo.getExecutionPipeline()) {
                int uDist = dist.get(u.getId());
                for (Long vId : adj.getOrDefault(u.getId(), Collections.emptyList())) {
                    TaskItem vTask = allTasks.stream().filter(t -> t.getId().equals(vId)).findFirst().orElse(null);
                    int vDur = (vTask != null && vTask.getEstimatedDurationHours() != null) ? vTask.getEstimatedDurationHours() : 8;
                    dist.put(vId, Math.max(dist.get(vId), uDist + vDur));
                }
            }
            criticalPathHours = dist.values().stream().max(Integer::compare).orElse(0);
        }

        GraphDiagnosticsDTO dto = new GraphDiagnosticsDTO();
        dto.setVertexCount(v);
        dto.setEdgeCount(e);
        dto.setGraphDensity(Math.round(density * 1000.0) / 1000.0);
        dto.setAcyclic(!topo.isHasCycle());
        dto.setMaxInDegree(maxIn);
        dto.setMaxOutDegree(maxOut);
        dto.setCriticalPathLengthHours(criticalPathHours);
        dto.setTimeComplexityNotation("O(V + E) = O(" + v + " + " + e + ")");
        dto.setSpaceComplexityNotation("O(V + E) [Adjacency List + Degree Array]");

        Map<String, String> theoretical = new LinkedHashMap<>();
        theoretical.put("Topological Sort (Kahn)", "Time: O(V + E) | Space: O(V)");
        theoretical.put("BFS Traversal", "Time: O(V + E) | Space: O(V)");
        theoretical.put("DFS Traversal", "Time: O(V + E) | Space: O(V)");
        theoretical.put("Min-Heap Dispatcher", "Time: O(V log V + E) | Space: O(V)");
        theoretical.put("Rabin-Karp String Match", "Time: O(N + M) avg, O(N*M) worst | Space: O(1)");
        theoretical.put("Critical Path Method (CPM)", "Time: O(V + E) via DP over DAG | Space: O(V)");
        dto.setTheoreticalComplexities(theoretical);

        Map<String, String> snippets = new LinkedHashMap<>();
        snippets.put("Kahn's Topological Sort", """
            // Kahn's Algorithm for Topological Sort & Deadlock Detection
            Queue<Node> zeroInDegreeQueue = new LinkedList<>();
            for (Node u : graph.getNodes()) {
                if (inDegree.get(u) == 0) zeroInDegreeQueue.offer(u);
            }
            List<Node> pipeline = new ArrayList<>();
            while (!zeroInDegreeQueue.isEmpty()) {
                Node u = zeroInDegreeQueue.poll();
                pipeline.add(u);
                for (Node v : graph.getNeighbors(u)) {
                    inDegree.put(v, inDegree.get(v) - 1);
                    if (inDegree.get(v) == 0) zeroInDegreeQueue.offer(v);
                }
            }
            boolean deadlockDetected = (pipeline.size() < graph.getNodeCount());
            """);

        snippets.put("Rabin-Karp Rolling Hash", """
            // Rabin-Karp Substring Matching with Polynomial Rolling Hash
            long pHash = 0, tHash = 0, h = 1;
            for (int i = 0; i < m - 1; i++) h = (h * D) % Q;
            for (int i = 0; i < m; i++) {
                pHash = (D * pHash + pattern.charAt(i)) % Q;
                tHash = (D * tHash + text.charAt(i)) % Q;
            }
            for (int i = 0; i <= n - m; i++) {
                if (pHash == tHash && checkExactMatch(i)) matches.add(i);
                if (i < n - m) {
                    tHash = (D * (tHash - text.charAt(i) * h) + text.charAt(i + m)) % Q;
                    if (tHash < 0) tHash += Q;
                }
            }
            """);

        snippets.put("Adaptive Min-Heap Dispatcher", """
            // Priority Queue (Min-Heap / Highest Priority First)
            PriorityQueue<TaskItem> readyHeap = new PriorityQueue<>((a, b) -> {
                int pCmp = Integer.compare(b.getPriorityWeight(), a.getPriorityWeight());
                return (pCmp != 0) ? pCmp : Integer.compare(a.getDuration(), b.getDuration());
            });
            while (!readyHeap.isEmpty()) {
                TaskItem nextTask = readyHeap.poll(); // O(log V)
                Worker worker = getWorkerWithEarliestAvailability();
                worker.assign(nextTask);
                updateDownstreamDependencies(nextTask, readyHeap);
            }
            """);

        dto.setAlgorithmCodeSnippets(snippets);
        return dto;
    }
}
