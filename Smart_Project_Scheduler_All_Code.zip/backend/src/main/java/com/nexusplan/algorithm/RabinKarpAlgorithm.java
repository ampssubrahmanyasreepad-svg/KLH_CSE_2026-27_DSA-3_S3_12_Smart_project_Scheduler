package com.nexusplan.algorithm;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Rabin-Karp Algorithm for Substring Pattern Matching
 * Uses polynomial rolling hash function:
 * H(S) = (s_0 * d^(m-1) + s_1 * d^(m-2) + ... + s_(m-1)) mod q
 * Average Time Complexity: O(n + m)
 * Space Complexity: O(1)
 */
@Component
public class RabinKarpAlgorithm {

    // Base for character set (ASCII 256)
    private static final int D = 256;
    // Prime number modulus to minimize hash collisions
    private static final long Q = 1000000007L;

    public static class MatchResult {
        private final List<Integer> indices;
        private final int comparisonsCount;
        private final int spuriousHits;
        private final long durationMicros;

        public MatchResult(List<Integer> indices, int comparisonsCount, int spuriousHits, long durationMicros) {
            this.indices = indices;
            this.comparisonsCount = comparisonsCount;
            this.spuriousHits = spuriousHits;
            this.durationMicros = durationMicros;
        }

        public List<Integer> getIndices() { return indices; }
        public int getComparisonsCount() { return comparisonsCount; }
        public int getSpuriousHits() { return spuriousHits; }
        public long getDurationMicros() { return durationMicros; }
    }

    public MatchResult search(String pattern, String text) {
        long startTime = System.nanoTime();
        List<Integer> indices = new ArrayList<>();

        if (pattern == null || text == null || pattern.isEmpty() || text.isEmpty()) {
            return new MatchResult(indices, 0, 0, 0);
        }

        // Case-insensitive search for research abstracts
        String pat = pattern.toLowerCase();
        String txt = text.toLowerCase();

        int m = pat.length();
        int n = txt.length();

        if (m > n) {
            return new MatchResult(indices, 0, 0, (System.nanoTime() - startTime) / 1000);
        }

        int comparisons = 0;
        int spuriousHits = 0;

        // The value of h would be "pow(d, m-1) % q"
        long h = 1;
        for (int i = 0; i < m - 1; i++) {
            h = (h * D) % Q;
        }

        long pHash = 0; // hash value for pattern
        long tHash = 0; // hash value for text window

        // Calculate initial hash values for pattern and first window of text
        for (int i = 0; i < m; i++) {
            pHash = (D * pHash + pat.charAt(i)) % Q;
            tHash = (D * tHash + txt.charAt(i)) % Q;
        }

        // Slide pattern over text one by one
        for (int i = 0; i <= n - m; i++) {
            // Check hash match
            if (pHash == tHash) {
                comparisons++;
                // Verify actual characters to guard against spurious collision
                boolean exactMatch = true;
                for (int j = 0; j < m; j++) {
                    if (txt.charAt(i + j) != pat.charAt(j)) {
                        exactMatch = false;
                        spuriousHits++;
                        break;
                    }
                }
                if (exactMatch) {
                    indices.add(i);
                }
            }

            // Calculate rolling hash value for next text window:
            // Remove leading digit, multiply by base, add trailing digit
            if (i < n - m) {
                tHash = (D * (tHash - txt.charAt(i) * h) + txt.charAt(i + m)) % Q;
                // If negative hash encountered, convert to positive
                if (tHash < 0) {
                    tHash = (tHash + Q);
                }
            }
        }

        long durationMicros = (System.nanoTime() - startTime) / 1000;
        return new MatchResult(indices, comparisons, spuriousHits, Math.max(1, durationMicros));
    }
}
