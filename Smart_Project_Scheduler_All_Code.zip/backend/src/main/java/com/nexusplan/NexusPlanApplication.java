package com.nexusplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexusPlanApplication {

    public static void main(String[] args) {
        SpringApplication.run(NexusPlanApplication.class, args);
    }
}
