package com.nexusplan.repository;

import com.nexusplan.model.TaskDependency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TaskDependencyRepository extends JpaRepository<TaskDependency, Long> {
    List<TaskDependency> findBySourceTaskId(Long sourceTaskId);
    List<TaskDependency> findByTargetTaskId(Long targetTaskId);
    Optional<TaskDependency> findBySourceTaskIdAndTargetTaskId(Long sourceTaskId, Long targetTaskId);
    void deleteBySourceTaskIdOrTargetTaskId(Long sourceTaskId, Long targetTaskId);
}
