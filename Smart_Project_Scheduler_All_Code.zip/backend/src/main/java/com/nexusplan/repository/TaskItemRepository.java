package com.nexusplan.repository;

import com.nexusplan.model.TaskItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TaskItemRepository extends JpaRepository<TaskItem, Long> {
    Optional<TaskItem> findByTaskKey(String taskKey);
    List<TaskItem> findByPaperId(Long paperId);
    List<TaskItem> findByStatus(String status);
    List<TaskItem> findByPriority(String priority);
}
