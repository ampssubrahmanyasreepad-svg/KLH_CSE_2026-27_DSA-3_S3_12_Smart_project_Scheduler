package com.nexusplan.controller;

import com.nexusplan.algorithm.GraphEngineService;
import com.nexusplan.dto.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/algorithms")
public class AlgorithmController {

    private final GraphEngineService graphEngineService;

    public AlgorithmController(GraphEngineService graphEngineService) {
        this.graphEngineService = graphEngineService;
    }

    @PostMapping("/bfs")
    public ResponseEntity<BfsResult> runBfs(@RequestBody(required = false) Map<String, Long> body) {
        Long startTaskId = (body != null) ? body.get("startTaskId") : null;
        return ResponseEntity.ok(graphEngineService.runBfs(startTaskId));
    }

    @PostMapping("/dfs")
    public ResponseEntity<DfsResult> runDfs(@RequestBody(required = false) Map<String, Long> body) {
        Long startTaskId = (body != null) ? body.get("startTaskId") : null;
        return ResponseEntity.ok(graphEngineService.runDfs(startTaskId));
    }

    @PostMapping("/topological-sort")
    public ResponseEntity<TopologicalSortResult> runTopologicalSort() {
        return ResponseEntity.ok(graphEngineService.runTopologicalSort());
    }

    @PostMapping("/dispatch")
    public ResponseEntity<DispatchScheduleResult> runDispatch(@RequestBody(required = false) Map<String, Integer> body) {
        int workers = (body != null && body.containsKey("workerCount")) ? body.get("workerCount") : 3;
        return ResponseEntity.ok(graphEngineService.runTaskDispatcher(workers));
    }

    @GetMapping("/diagnostics")
    public ResponseEntity<GraphDiagnosticsDTO> getDiagnostics() {
        return ResponseEntity.ok(graphEngineService.getDiagnostics());
    }
}
