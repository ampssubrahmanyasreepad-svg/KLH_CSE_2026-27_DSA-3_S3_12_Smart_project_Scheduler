package com.nexusplan.controller;

import com.nexusplan.service.SeedDataService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/seed")
public class SeedDataController {

    private final SeedDataService seedDataService;

    public SeedDataController(SeedDataService seedDataService) {
        this.seedDataService = seedDataService;
    }

    @PostMapping
    public ResponseEntity<?> seedDatabase() {
        seedDataService.seedInitialData();
        return ResponseEntity.ok(Map.of("message", "Database successfully seeded with research papers, tasks, and clean DAG execution graph!"));
    }
}
