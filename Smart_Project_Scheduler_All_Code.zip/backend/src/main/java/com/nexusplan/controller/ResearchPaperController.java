package com.nexusplan.controller;

import com.nexusplan.dto.RabinKarpSearchResult;
import com.nexusplan.model.ResearchPaper;
import com.nexusplan.service.ResearchPaperService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/papers")
public class ResearchPaperController {

    private final ResearchPaperService paperService;

    public ResearchPaperController(ResearchPaperService paperService) {
        this.paperService = paperService;
    }

    @GetMapping
    public ResponseEntity<List<ResearchPaper>> getAllPapers() {
        return ResponseEntity.ok(paperService.getAllPapers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getPaperById(@PathVariable Long id) {
        return paperService.getPaperById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ResearchPaper> createPaper(@RequestBody ResearchPaper paper) {
        return ResponseEntity.ok(paperService.createPaper(paper));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updatePaper(@PathVariable Long id, @RequestBody ResearchPaper paper) {
        try {
            return ResponseEntity.ok(paperService.updatePaper(id, paper));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePaper(@PathVariable Long id) {
        paperService.deletePaper(id);
        return ResponseEntity.ok(Map.of("message", "Research paper deleted successfully"));
    }

    /**
     * Rabin-Karp Substring Matching Search Endpoint
     */
    @PostMapping("/search")
    public ResponseEntity<RabinKarpSearchResult> searchWithRabinKarp(@RequestBody Map<String, String> body) {
        String query = body.getOrDefault("query", "");
        return ResponseEntity.ok(paperService.searchWithRabinKarp(query));
    }

    @GetMapping("/search")
    public ResponseEntity<RabinKarpSearchResult> searchWithRabinKarpGet(@RequestParam(name = "q", defaultValue = "") String query) {
        return ResponseEntity.ok(paperService.searchWithRabinKarp(query));
    }
}
