package com.nexusplan.controller;

import com.nexusplan.model.TaskDependency;
import com.nexusplan.service.TaskService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dependencies")
public class DependencyController {

    private final TaskService taskService;

    public DependencyController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<List<TaskDependency>> getAllDependencies() {
        return ResponseEntity.ok(taskService.getAllDependencies());
    }

    @PostMapping
    public ResponseEntity<?> addDependency(@RequestBody Map<String, Object> body) {
        try {
            Long sourceTaskId = Long.valueOf(body.get("sourceTaskId").toString());
            Long targetTaskId = Long.valueOf(body.get("targetTaskId").toString());
            String type = (String) body.getOrDefault("dependencyType", "HARD");
            String label = (String) body.getOrDefault("label", "");

            TaskDependency dep = taskService.addDependency(sourceTaskId, targetTaskId, type, label);
            return ResponseEntity.ok(dep);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Failed to add dependency: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDependency(@PathVariable Long id) {
        taskService.deleteDependency(id);
        return ResponseEntity.ok(Map.of("message", "Dependency edge removed"));
    }

    /**
     * Toggles a circular deadlock back-edge to demonstrate Kahn's algorithm cycle detection ($A -> B -> A$).
     */
    @PostMapping("/toggle-deadlock")
    public ResponseEntity<?> toggleDeadlock() {
        return ResponseEntity.ok(taskService.toggleDeadlockScenario());
    }
}
