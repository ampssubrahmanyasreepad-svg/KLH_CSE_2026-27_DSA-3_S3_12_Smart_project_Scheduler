package com.nexusplan.service;

import com.nexusplan.model.TaskDependency;
import com.nexusplan.model.TaskItem;
import com.nexusplan.repository.TaskDependencyRepository;
import com.nexusplan.repository.TaskItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TaskService {

    private final TaskItemRepository taskRepository;
    private final TaskDependencyRepository dependencyRepository;

    public TaskService(TaskItemRepository taskRepository, TaskDependencyRepository dependencyRepository) {
        this.taskRepository = taskRepository;
        this.dependencyRepository = dependencyRepository;
    }

    public List<TaskItem> getAllTasks() {
        return taskRepository.findAll();
    }

    public Optional<TaskItem> getTaskById(Long id) {
        return taskRepository.findById(id);
    }

    public TaskItem createTask(TaskItem task) {
        if (task.getTaskKey() == null || task.getTaskKey().trim().isEmpty()) {
            task.setTaskKey("TASK-" + String.format("%02d", taskRepository.count() + 1));
        }
        return taskRepository.save(task);
    }

    public TaskItem updateTask(Long id, TaskItem updated) {
        return taskRepository.findById(id).map(existing -> {
            existing.setTitle(updated.getTitle());
            existing.setDescription(updated.getDescription());
            existing.setStatus(updated.getStatus());
            existing.setPriority(updated.getPriority());
            existing.setEstimatedDurationHours(updated.getEstimatedDurationHours());
            existing.setDeadline(updated.getDeadline());
            existing.setPaperId(updated.getPaperId());
            existing.setPaperTitle(updated.getPaperTitle());
            existing.setColorTag(updated.getColorTag());
            if (updated.getPositionX() != null) existing.setPositionX(updated.getPositionX());
            if (updated.getPositionY() != null) existing.setPositionY(updated.getPositionY());
            return taskRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Task not found with id: " + id));
    }

    public void updateTaskPosition(Long id, Double x, Double y) {
        taskRepository.findById(id).ifPresent(task -> {
            task.setPositionX(x);
            task.setPositionY(y);
            taskRepository.save(task);
        });
    }

    @Transactional
    public void deleteTask(Long id) {
        dependencyRepository.deleteBySourceTaskIdOrTargetTaskId(id, id);
        taskRepository.deleteById(id);
    }

    // Dependencies
    public List<TaskDependency> getAllDependencies() {
        return dependencyRepository.findAll();
    }

    public TaskDependency addDependency(Long sourceTaskId, Long targetTaskId, String dependencyType, String label) {
        if (sourceTaskId.equals(targetTaskId)) {
            throw new IllegalArgumentException("Self-dependency is not allowed: Task cannot depend on itself.");
        }
        // Check if exists
        Optional<TaskDependency> existing = dependencyRepository.findBySourceTaskIdAndTargetTaskId(sourceTaskId, targetTaskId);
        if (existing.isPresent()) {
            return existing.get();
        }
        TaskDependency edge = new TaskDependency(sourceTaskId, targetTaskId,
                dependencyType != null ? dependencyType : "HARD", label);
        return dependencyRepository.save(edge);
    }

    public void deleteDependency(Long id) {
        dependencyRepository.deleteById(id);
    }

    /**
     * Toggles a circular deadlock back-edge to demonstrate Kahn's algorithm cycle detection ($A -> B -> A$).
     */
    @Transactional
    public Map<String, Object> toggleDeadlockScenario() {
        List<TaskItem> tasks = taskRepository.findAll();
        Map<String, Object> response = new HashMap<>();

        if (tasks.size() < 2) {
            response.put("success", false);
            response.put("message", "Need at least 2 tasks to demonstrate circular deadlock.");
            return response;
        }

        TaskItem taskA = tasks.get(0);
        TaskItem taskB = tasks.get(1);

        // Check if cycle edge B -> A exists
        Optional<TaskDependency> cycleEdge = dependencyRepository.findBySourceTaskIdAndTargetTaskId(taskB.getId(), taskA.getId());
        if (cycleEdge.isPresent()) {
            // Remove cycle edge
            dependencyRepository.delete(cycleEdge.get());
            response.put("deadlockActive", false);
            response.put("message", "Deadlock edge removed (" + taskB.getTaskKey() + " ➔ " + taskA.getTaskKey() + "). Graph is now a clean DAG.");
        } else {
            // Ensure forward edge A -> B exists
            if (dependencyRepository.findBySourceTaskIdAndTargetTaskId(taskA.getId(), taskB.getId()).isEmpty()) {
                dependencyRepository.save(new TaskDependency(taskA.getId(), taskB.getId(), "HARD", "Precedes"));
            }
            // Add back edge B -> A creating cycle A <-> B
            dependencyRepository.save(new TaskDependency(taskB.getId(), taskA.getId(), "HARD", "Deadlock Cycle"));
            response.put("deadlockActive", true);
            response.put("message", "Circular Deadlock Injected: " + taskA.getTaskKey() + " ➔ " + taskB.getTaskKey() + " ➔ " + taskA.getTaskKey());
        }

        return response;
    }
}
