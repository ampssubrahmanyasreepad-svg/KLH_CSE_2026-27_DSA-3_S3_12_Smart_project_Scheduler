package com.nexusplan.service;

import com.nexusplan.algorithm.GraphEngineService;
import com.nexusplan.dto.DashboardStatsDTO;
import com.nexusplan.dto.TopologicalSortResult;
import com.nexusplan.model.TaskDependency;
import com.nexusplan.model.TaskItem;
import com.nexusplan.repository.ResearchPaperRepository;
import com.nexusplan.repository.TaskDependencyRepository;
import com.nexusplan.repository.TaskItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final TaskItemRepository taskRepository;
    private final TaskDependencyRepository dependencyRepository;
    private final ResearchPaperRepository paperRepository;
    private final GraphEngineService graphEngineService;

    public DashboardService(TaskItemRepository taskRepository,
                            TaskDependencyRepository dependencyRepository,
                            ResearchPaperRepository paperRepository,
                            GraphEngineService graphEngineService) {
        this.taskRepository = taskRepository;
        this.dependencyRepository = dependencyRepository;
        this.paperRepository = paperRepository;
        this.graphEngineService = graphEngineService;
    }

    public DashboardStatsDTO getStats() {
        List<TaskItem> tasks = taskRepository.findAll();
        List<TaskDependency> edges = dependencyRepository.findAll();
        long paperCount = paperRepository.count();

        int totalTasks = tasks.size();
        int completed = (int) tasks.stream().filter(t -> "COMPLETED".equalsIgnoreCase(t.getStatus())).count();
        int inProgress = (int) tasks.stream().filter(t -> "IN_PROGRESS".equalsIgnoreCase(t.getStatus())).count();
        int ready = (int) tasks.stream().filter(t -> "READY".equalsIgnoreCase(t.getStatus())).count();
        int blocked = (int) tasks.stream().filter(t -> "BLOCKED".equalsIgnoreCase(t.getStatus())).count();

        double completionRate = totalTasks > 0 ? ((double) completed / totalTasks) * 100.0 : 0.0;

        Map<String, Long> priorityDist = tasks.stream()
                .collect(Collectors.groupingBy(t -> t.getPriority() != null ? t.getPriority() : "MEDIUM", Collectors.counting()));

        Map<String, Long> statusDist = tasks.stream()
                .collect(Collectors.groupingBy(t -> t.getStatus() != null ? t.getStatus() : "READY", Collectors.counting()));

        TopologicalSortResult topo = graphEngineService.runTopologicalSort();

        DashboardStatsDTO dto = new DashboardStatsDTO();
        dto.setTotalTasks(totalTasks);
        dto.setCompletedTasks(completed);
        dto.setInProgressTasks(inProgress);
        dto.setReadyTasks(ready);
        dto.setBlockedTasks(blocked);
        dto.setCompletionRate(Math.round(completionRate * 10.0) / 10.0);
        dto.setTotalPapers((int) paperCount);
        dto.setGraphVertexCount(totalTasks);
        dto.setGraphEdgeCount(edges.size());
        dto.setDagValid(!topo.isHasCycle());
        dto.setCriticalPathHours(graphEngineService.getDiagnostics().getCriticalPathLengthHours());
        dto.setPriorityDistribution(priorityDist);
        dto.setStatusDistribution(statusDist);

        return dto;
    }
}
