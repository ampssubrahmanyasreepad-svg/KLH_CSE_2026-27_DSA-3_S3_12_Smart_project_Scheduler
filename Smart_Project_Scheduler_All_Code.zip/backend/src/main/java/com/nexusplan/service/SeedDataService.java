package com.nexusplan.service;

import com.nexusplan.model.ResearchPaper;
import com.nexusplan.model.TaskDependency;
import com.nexusplan.model.TaskItem;
import com.nexusplan.model.User;
import com.nexusplan.repository.ResearchPaperRepository;
import com.nexusplan.repository.TaskDependencyRepository;
import com.nexusplan.repository.TaskItemRepository;
import com.nexusplan.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class SeedDataService implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ResearchPaperRepository paperRepository;
    private final TaskItemRepository taskRepository;
    private final TaskDependencyRepository dependencyRepository;
    private final PasswordEncoder passwordEncoder;

    public SeedDataService(UserRepository userRepository,
                           ResearchPaperRepository paperRepository,
                           TaskItemRepository taskRepository,
                           TaskDependencyRepository dependencyRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.paperRepository = paperRepository;
        this.taskRepository = taskRepository;
        this.dependencyRepository = dependencyRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (taskRepository.count() == 0) {
            seedInitialData();
        }
    }

    @Transactional
    public void seedInitialData() {
        // 1. Seed User
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User("admin", "admin@nexusplan.io", passwordEncoder.encode("nexus123"), "Lead Architect", "ROLE_ADMIN");
            userRepository.save(admin);
        }

        // Clear existing for clean seed
        dependencyRepository.deleteAll();
        taskRepository.deleteAll();
        paperRepository.deleteAll();

        // 2. Seed Seminal Research Papers
        ResearchPaper p1 = new ResearchPaper(
                "Attention Is All You Need",
                "Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Łukasz Kaiser, Illia Polosukhin",
                2017,
                "NeurIPS",
                "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks that include an encoder and a decoder. The best performing models also connect the encoder and decoder through an attention mechanism. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely. Experiments on two machine translation tasks show these models to be superior in quality while being more parallelizable and requiring significantly less time to train.",
                "Multi-Head Self-Attention using Scaled Dot-Product Attention: Attention(Q, K, V) = softmax(QK^T / sqrt(d_k))V. Replaces RNN recurrent passes with O(1) sequential path length.",
                "https://arxiv.org/abs/1706.03762",
                "Transformer, Attention, Deep Learning, Natural Language Processing, Parallel Computing"
        );

        ResearchPaper p2 = new ResearchPaper(
                "FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness",
                "Tri Dao, Daniel Y. Fu, Stefano Ermon, Atri Rudra, Christopher Ré",
                2022,
                "NeurIPS",
                "Transformers are slow and memory-intensive on long sequences, as the time and memory complexity of self-attention are quadratic in sequence length. Approximate attention methods have attempted to address this by trading off model quality to reduce the compute complexity, but often do not achieve wall-clock speedup. We argue that a missing principle is making attention algorithms IO-aware—accounting for reads and writes between levels of GPU memory. We propose FlashAttention, an IO-aware exact attention algorithm that uses tiling to reduce the number of memory reads/writes between GPU high bandwidth memory (HBM) and GPU on-chip SRAM.",
                "Tiling and online softmax computation to compute exact attention without materializing the full N x N attention matrix in slow GPU HBM. Achieves 2-4x wall-clock speedup.",
                "https://arxiv.org/abs/2205.14135",
                "GPU Acceleration, FlashAttention, IO Complexity, Tiling, Exact Attention"
        );

        ResearchPaper p3 = new ResearchPaper(
                "Deep Residual Learning for Image Recognition",
                "Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun",
                2015,
                "CVPR",
                "Deeper neural networks are more difficult to train. We present a residual learning framework to ease the training of networks that are substantially deeper than those used previously. We explicitly reformulate the layers as learning residual functions with reference to the layer inputs, instead of learning unreferenced functions. We provide comprehensive empirical evidence showing that these residual networks are easier to optimize, and can gain accuracy from considerably increased depth.",
                "Shortcut identity mappings: H(x) = F(x) + x. Mitigates vanishing/exploding gradients through backpropagation paths that traverse identity shortcuts directly.",
                "https://arxiv.org/abs/1512.03385",
                "Residual Learning, ResNet, Computer Vision, Skip Connection, Backpropagation"
        );

        ResearchPaper p4 = new ResearchPaper(
                "MapReduce: Simplified Data Processing on Large Clusters",
                "Jeffrey Dean, Sanjay Ghemawat",
                2004,
                "OSDI",
                "MapReduce is a programming model and an associated implementation for processing and generating large data sets. Users specify a map function that processes a key/value pair to generate a set of intermediate key/value pairs, and a reduce function that merges all intermediate values associated with the same intermediate key. Programs written in this functional style are automatically parallelized and executed on a large cluster of commodity machines.",
                "Partitioned distributed execution with master worker node scheduling, deterministic key-range hashing, re-execution of failed worker tasks.",
                "https://research.google/pubs/pub62/",
                "Distributed Systems, MapReduce, Big Data, Fault Tolerance, Parallel Scheduling"
        );

        List<ResearchPaper> savedPapers = paperRepository.saveAll(List.of(p1, p2, p3, p4));
        ResearchPaper paper1 = savedPapers.get(0);
        ResearchPaper paper2 = savedPapers.get(1);
        ResearchPaper paper3 = savedPapers.get(2);
        ResearchPaper paper4 = savedPapers.get(3);

        // 3. Seed Execution Topology Tasks (DAG Nodes)
        TaskItem t1 = new TaskItem("TASK-01", "Tokenizer & Vocabulary Ingestion Engine",
                "Construct BPE tokenizer and string dictionary lookup with zero-copy buffer allocations.",
                "COMPLETED", "HIGH", 6, LocalDate.now().plusDays(3),
                paper1.getId(), paper1.getTitle(), "#38BDF8", 80.0, 160.0);

        TaskItem t2 = new TaskItem("TASK-02", "Multi-Head Attention Vector Compute Kernel",
                "Implement scaled dot-product attention QK^T / sqrt(d_k) with multi-threaded matrix multiplication.",
                "IN_PROGRESS", "CRITICAL", 12, LocalDate.now().plusDays(5),
                paper1.getId(), paper1.getTitle(), "#8B5CF6", 340.0, 80.0);

        TaskItem t3 = new TaskItem("TASK-03", "Sinusoidal Positional Encoding Module",
                "Generate fixed wavelength frequency geometric embeddings for spatial position tracking.",
                "COMPLETED", "MEDIUM", 4, LocalDate.now().plusDays(4),
                paper1.getId(), paper1.getTitle(), "#38BDF8", 340.0, 240.0);

        TaskItem t4 = new TaskItem("TASK-04", "Residual Skip & LayerNorm Integration",
                "Add identity shortcut connections H(x) = F(x) + x with fused root mean square normalization.",
                "READY", "HIGH", 8, LocalDate.now().plusDays(7),
                paper3.getId(), paper3.getTitle(), "#10B981", 600.0, 160.0);

        TaskItem t5 = new TaskItem("TASK-05", "SRAM Memory Tiling & IO Optimizer",
                "Implement FlashAttention fast block tiling across GPU on-chip SRAM caches to eliminate HBM latency.",
                "READY", "CRITICAL", 16, LocalDate.now().plusDays(8),
                paper2.getId(), paper2.getTitle(), "#F59E0B", 600.0, 320.0);

        TaskItem t6 = new TaskItem("TASK-06", "Distributed Task Sharder & MapReduce Pipeline",
                "Coordinate distributed partition shuffling and reduce aggregation across worker nodes.",
                "PENDING", "HIGH", 14, LocalDate.now().plusDays(10),
                paper4.getId(), paper4.getTitle(), "#8B5CF6", 860.0, 200.0);

        TaskItem t7 = new TaskItem("TASK-07", "Latency & Flops Algorithmic Profiler",
                "Benchmark end-to-end execution latency, memory footprint, and graph traversal efficiency metrics.",
                "PENDING", "MEDIUM", 6, LocalDate.now().plusDays(12),
                paper2.getId(), paper2.getTitle(), "#38BDF8", 1120.0, 140.0);

        TaskItem t8 = new TaskItem("TASK-08", "Autonomous Dispatcher Deployment Service",
                "Deploy self-healing Min-Heap priority scheduler to live production cluster.",
                "PENDING", "LOW", 4, LocalDate.now().plusDays(14),
                paper4.getId(), paper4.getTitle(), "#10B981", 1120.0, 280.0);

        List<TaskItem> savedTasks = taskRepository.saveAll(List.of(t1, t2, t3, t4, t5, t6, t7, t8));

        // 4. Seed Dependencies (DAG Directed Edges: source must execute before target)
        // t1 (Tokenizer) -> t2 (Multi-Head Attention)
        // t1 (Tokenizer) -> t3 (Positional Encoding)
        // t2 & t3 -> t4 (Residual Skip & LayerNorm)
        // t2 -> t5 (SRAM Tiling Optimizer)
        // t4 & t5 -> t6 (Distributed Sharder)
        // t6 -> t7 (Algorithmic Profiler)
        // t6 -> t8 (Autonomous Dispatcher)
        // t7 -> t8 (Final Production Deployment)
        dependencyRepository.save(new TaskDependency(savedTasks.get(0).getId(), savedTasks.get(1).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(0).getId(), savedTasks.get(2).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(1).getId(), savedTasks.get(3).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(2).getId(), savedTasks.get(3).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(1).getId(), savedTasks.get(4).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(3).getId(), savedTasks.get(5).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(4).getId(), savedTasks.get(5).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(5).getId(), savedTasks.get(6).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(5).getId(), savedTasks.get(7).getId(), "HARD", "Precedes"));
        dependencyRepository.save(new TaskDependency(savedTasks.get(6).getId(), savedTasks.get(7).getId(), "HARD", "Precedes"));
    }
}
