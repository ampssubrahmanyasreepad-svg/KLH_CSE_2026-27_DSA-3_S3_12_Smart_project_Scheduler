package com.nexusplan.service;

import com.nexusplan.algorithm.RabinKarpAlgorithm;
import com.nexusplan.dto.RabinKarpSearchResult;
import com.nexusplan.model.ResearchPaper;
import com.nexusplan.repository.ResearchPaperRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ResearchPaperService {

    private final ResearchPaperRepository paperRepository;
    private final RabinKarpAlgorithm rabinKarpAlgorithm;

    public ResearchPaperService(ResearchPaperRepository paperRepository, RabinKarpAlgorithm rabinKarpAlgorithm) {
        this.paperRepository = paperRepository;
        this.rabinKarpAlgorithm = rabinKarpAlgorithm;
    }

    public List<ResearchPaper> getAllPapers() {
        return paperRepository.findAll();
    }

    public Optional<ResearchPaper> getPaperById(Long id) {
        return paperRepository.findById(id);
    }

    public ResearchPaper createPaper(ResearchPaper paper) {
        return paperRepository.save(paper);
    }

    public ResearchPaper updatePaper(Long id, ResearchPaper updated) {
        return paperRepository.findById(id).map(existing -> {
            existing.setTitle(updated.getTitle());
            existing.setAuthors(updated.getAuthors());
            existing.setPublicationYear(updated.getPublicationYear());
            existing.setPublicationVenue(updated.getPublicationVenue());
            existing.setAbstractText(updated.getAbstractText());
            existing.setMethodology(updated.getMethodology());
            existing.setArxivUrl(updated.getArxivUrl());
            existing.setTags(updated.getTags());
            return paperRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Paper not found with id: " + id));
    }

    public void deletePaper(Long id) {
        paperRepository.deleteById(id);
    }

    /**
     * Rabin-Karp Substring Search across Research Papers abstracts and methodologies.
     */
    public RabinKarpSearchResult searchWithRabinKarp(String query) {
        List<ResearchPaper> papers = paperRepository.findAll();
        RabinKarpSearchResult result = new RabinKarpSearchResult();
        result.setQuery(query);

        if (query == null || query.trim().isEmpty()) {
            return result;
        }

        long totalDurationMicros = 0;
        int totalMatches = 0;
        int totalComparisons = 0;
        int totalSpurious = 0;

        List<RabinKarpSearchResult.PaperMatchOccurrence> occurrences = new ArrayList<>();

        for (ResearchPaper paper : papers) {
            String fullSearchableText = (paper.getTitle() + " " + paper.getAbstractText() + " " + (paper.getMethodology() != null ? paper.getMethodology() : ""));
            RabinKarpAlgorithm.MatchResult matchRes = rabinKarpAlgorithm.search(query, fullSearchableText);

            totalDurationMicros += matchRes.getDurationMicros();
            totalComparisons += matchRes.getComparisonsCount();
            totalSpurious += matchRes.getSpuriousHits();

            if (!matchRes.getIndices().isEmpty()) {
                totalMatches += matchRes.getIndices().size();
                List<String> snippets = new ArrayList<>();

                for (int idx : matchRes.getIndices()) {
                    int start = Math.max(0, idx - 40);
                    int end = Math.min(fullSearchableText.length(), idx + query.length() + 40);
                    String snippet = (start > 0 ? "..." : "") +
                            fullSearchableText.substring(start, end) +
                            (end < fullSearchableText.length() ? "..." : "");
                    snippets.add(snippet);
                }

                occurrences.add(new RabinKarpSearchResult.PaperMatchOccurrence(
                        paper.getId(),
                        paper.getTitle(),
                        matchRes.getIndices(),
                        snippets
                ));
            }
        }

        result.setTotalMatches(totalMatches);
        result.setExecutionTimeMicros(totalDurationMicros);
        result.setTotalHashComparisons(totalComparisons);
        result.setSpuriousHits(totalSpurious);
        result.setMatches(occurrences);

        return result;
    }
}
