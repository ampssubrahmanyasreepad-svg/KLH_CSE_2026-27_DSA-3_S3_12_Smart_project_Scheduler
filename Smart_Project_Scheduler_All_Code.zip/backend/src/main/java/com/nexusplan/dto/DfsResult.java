package com.nexusplan.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DfsResult {
    private Long startTaskId;
    private String startTaskKey;
    private List<String> traversalOrder = new ArrayList<>();
    private List<DfsStep> steps = new ArrayList<>();
    private Map<String, Integer> discoveryTimes;
    private Map<String, Integer> finishTimes;
    private List<String> backEdges = new ArrayList<>(); // Cycle indicators
    private long executionTimeMicros;

    public static class DfsStep {
        private int stepNumber;
        private String currentNode;
        private List<String> callStack;
        private List<String> visitedNodes;
        private String edgeType; // TREE, BACK, FORWARD, CROSS
        private String actionMessage;

        public DfsStep() {}
        public DfsStep(int stepNumber, String currentNode, List<String> callStack,
                       List<String> visitedNodes, String edgeType, String actionMessage) {
            this.stepNumber = stepNumber;
            this.currentNode = currentNode;
            this.callStack = callStack;
            this.visitedNodes = visitedNodes;
            this.edgeType = edgeType;
            this.actionMessage = actionMessage;
        }

        public int getStepNumber() { return stepNumber; }
        public void setStepNumber(int stepNumber) { this.stepNumber = stepNumber; }
        public String getCurrentNode() { return currentNode; }
        public void setCurrentNode(String currentNode) { this.currentNode = currentNode; }
        public List<String> getCallStack() { return callStack; }
        public void setCallStack(List<String> callStack) { this.callStack = callStack; }
        public List<String> getVisitedNodes() { return visitedNodes; }
        public void setVisitedNodes(List<String> visitedNodes) { this.visitedNodes = visitedNodes; }
        public String getEdgeType() { return edgeType; }
        public void setEdgeType(String edgeType) { this.edgeType = edgeType; }
        public String getActionMessage() { return actionMessage; }
        public void setActionMessage(String actionMessage) { this.actionMessage = actionMessage; }
    }

    public DfsResult() {}

    public Long getStartTaskId() { return startTaskId; }
    public void setStartTaskId(Long startTaskId) { this.startTaskId = startTaskId; }
    public String getStartTaskKey() { return startTaskKey; }
    public void setStartTaskKey(String startTaskKey) { this.startTaskKey = startTaskKey; }
    public List<String> getTraversalOrder() { return traversalOrder; }
    public void setTraversalOrder(List<String> traversalOrder) { this.traversalOrder = traversalOrder; }
    public List<DfsStep> getSteps() { return steps; }
    public void setSteps(List<DfsStep> steps) { this.steps = steps; }
    public Map<String, Integer> getDiscoveryTimes() { return discoveryTimes; }
    public void setDiscoveryTimes(Map<String, Integer> discoveryTimes) { this.discoveryTimes = discoveryTimes; }
    public Map<String, Integer> getFinishTimes() { return finishTimes; }
    public void setFinishTimes(Map<String, Integer> finishTimes) { this.finishTimes = finishTimes; }
    public List<String> getBackEdges() { return backEdges; }
    public void setBackEdges(List<String> backEdges) { this.backEdges = backEdges; }
    public long getExecutionTimeMicros() { return executionTimeMicros; }
    public void setExecutionTimeMicros(long executionTimeMicros) { this.executionTimeMicros = executionTimeMicros; }
}
