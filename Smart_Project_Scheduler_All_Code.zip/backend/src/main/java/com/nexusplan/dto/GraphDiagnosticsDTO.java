package com.nexusplan.dto;

import java.util.Map;

public class GraphDiagnosticsDTO {
    private int vertexCount;
    private int edgeCount;
    private double graphDensity;
    private boolean isAcyclic;
    private int maxInDegree;
    private int maxOutDegree;
    private int criticalPathLengthHours;
    private String timeComplexityNotation;
    private String spaceComplexityNotation;
    private Map<String, String> algorithmCodeSnippets;
    private Map<String, String> theoreticalComplexities;

    public GraphDiagnosticsDTO() {}

    public int getVertexCount() { return vertexCount; }
    public void setVertexCount(int vertexCount) { this.vertexCount = vertexCount; }
    public int getEdgeCount() { return edgeCount; }
    public void setEdgeCount(int edgeCount) { this.edgeCount = edgeCount; }
    public double getGraphDensity() { return graphDensity; }
    public void setGraphDensity(double graphDensity) { this.graphDensity = graphDensity; }
    public boolean isAcyclic() { return isAcyclic; }
    public void setAcyclic(boolean acyclic) { isAcyclic = acyclic; }
    public int getMaxInDegree() { return maxInDegree; }
    public void setMaxInDegree(int maxInDegree) { this.maxInDegree = maxInDegree; }
    public int getMaxOutDegree() { return maxOutDegree; }
    public void setMaxOutDegree(int maxOutDegree) { this.maxOutDegree = maxOutDegree; }
    public int getCriticalPathLengthHours() { return criticalPathLengthHours; }
    public void setCriticalPathLengthHours(int criticalPathLengthHours) { this.criticalPathLengthHours = criticalPathLengthHours; }
    public String getTimeComplexityNotation() { return timeComplexityNotation; }
    public void setTimeComplexityNotation(String timeComplexityNotation) { this.timeComplexityNotation = timeComplexityNotation; }
    public String getSpaceComplexityNotation() { return spaceComplexityNotation; }
    public void setSpaceComplexityNotation(String spaceComplexityNotation) { this.spaceComplexityNotation = spaceComplexityNotation; }
    public Map<String, String> getAlgorithmCodeSnippets() { return algorithmCodeSnippets; }
    public void setAlgorithmCodeSnippets(Map<String, String> algorithmCodeSnippets) { this.algorithmCodeSnippets = algorithmCodeSnippets; }
    public Map<String, String> getTheoreticalComplexities() { return theoreticalComplexities; }
    public void setTheoreticalComplexities(Map<String, String> theoreticalComplexities) { this.theoreticalComplexities = theoreticalComplexities; }
}
