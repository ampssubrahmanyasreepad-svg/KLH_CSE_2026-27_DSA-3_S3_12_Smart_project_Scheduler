package com.nexusplan.dto;

import java.util.ArrayList;
import java.util.List;

public class RabinKarpSearchResult {
    private String query;
    private int totalMatches;
    private long executionTimeMicros;
    private int totalHashComparisons;
    private int spuriousHits; // Collisions where hashes matched but strings differed
    private List<PaperMatchOccurrence> matches = new ArrayList<>();

    public static class PaperMatchOccurrence {
        private Long paperId;
        private String paperTitle;
        private List<Integer> matchIndices = new ArrayList<>();
        private List<String> snippets = new ArrayList<>();

        public PaperMatchOccurrence() {}

        public PaperMatchOccurrence(Long paperId, String paperTitle, List<Integer> matchIndices, List<String> snippets) {
            this.paperId = paperId;
            this.paperTitle = paperTitle;
            this.matchIndices = matchIndices;
            this.snippets = snippets;
        }

        public Long getPaperId() { return paperId; }
        public void setPaperId(Long paperId) { this.paperId = paperId; }
        public String getPaperTitle() { return paperTitle; }
        public void setPaperTitle(String paperTitle) { this.paperTitle = paperTitle; }
        public List<Integer> getMatchIndices() { return matchIndices; }
        public void setMatchIndices(List<Integer> matchIndices) { this.matchIndices = matchIndices; }
        public List<String> getSnippets() { return snippets; }
        public void setSnippets(List<String> snippets) { this.snippets = snippets; }
    }

    public RabinKarpSearchResult() {}

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }
    public int getTotalMatches() { return totalMatches; }
    public void setTotalMatches(int totalMatches) { this.totalMatches = totalMatches; }
    public long getExecutionTimeMicros() { return executionTimeMicros; }
    public void setExecutionTimeMicros(long executionTimeMicros) { this.executionTimeMicros = executionTimeMicros; }
    public int getTotalHashComparisons() { return totalHashComparisons; }
    public void setTotalHashComparisons(int totalHashComparisons) { this.totalHashComparisons = totalHashComparisons; }
    public int getSpuriousHits() { return spuriousHits; }
    public void setSpuriousHits(int spuriousHits) { this.spuriousHits = spuriousHits; }
    public List<PaperMatchOccurrence> getMatches() { return matches; }
    public void setMatches(List<PaperMatchOccurrence> matches) { this.matches = matches; }
}
