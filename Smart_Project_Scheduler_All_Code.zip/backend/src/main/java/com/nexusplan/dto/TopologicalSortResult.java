package com.nexusplan.dto;

import com.nexusplan.model.TaskItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TopologicalSortResult {
    private boolean hasCycle;
    private boolean deadlockDetected;
    private List<TaskItem> executionPipeline = new ArrayList<>();
    private List<String> executionOrderKeys = new ArrayList<>();
    private List<String> cycleNodes = new ArrayList<>();
    private List<String> cycleEdgeDescriptions = new ArrayList<>();
    private Map<String, Integer> initialInDegrees;
    private List<TopologicalStep> steps = new ArrayList<>();
    private String diagnosticMessage;
    private long executionTimeMicros;

    public static class TopologicalStep {
        private int stepNumber;
        private String processedNodeKey;
        private List<String> zeroInDegreeQueue;
        private Map<String, Integer> currentInDegrees;
        private List<String> currentResolvedPipeline;
        private String actionMessage;

        public TopologicalStep() {}
        public TopologicalStep(int stepNumber, String processedNodeKey, List<String> zeroInDegreeQueue,
                               Map<String, Integer> currentInDegrees, List<String> currentResolvedPipeline, String actionMessage) {
            this.stepNumber = stepNumber;
            this.processedNodeKey = processedNodeKey;
            this.zeroInDegreeQueue = zeroInDegreeQueue;
            this.currentInDegrees = currentInDegrees;
            this.currentResolvedPipeline = currentResolvedPipeline;
            this.actionMessage = actionMessage;
        }

        public int getStepNumber() { return stepNumber; }
        public void setStepNumber(int stepNumber) { this.stepNumber = stepNumber; }
        public String getProcessedNodeKey() { return processedNodeKey; }
        public void setProcessedNodeKey(String processedNodeKey) { this.processedNodeKey = processedNodeKey; }
        public List<String> getZeroInDegreeQueue() { return zeroInDegreeQueue; }
        public void setZeroInDegreeQueue(List<String> zeroInDegreeQueue) { this.zeroInDegreeQueue = zeroInDegreeQueue; }
        public Map<String, Integer> getCurrentInDegrees() { return currentInDegrees; }
        public void setCurrentInDegrees(Map<String, Integer> currentInDegrees) { this.currentInDegrees = currentInDegrees; }
        public List<String> getCurrentResolvedPipeline() { return currentResolvedPipeline; }
        public void setCurrentResolvedPipeline(List<String> currentResolvedPipeline) { this.currentResolvedPipeline = currentResolvedPipeline; }
        public String getActionMessage() { return actionMessage; }
        public void setActionMessage(String actionMessage) { this.actionMessage = actionMessage; }
    }

    public TopologicalSortResult() {}

    public boolean isHasCycle() { return hasCycle; }
    public void setHasCycle(boolean hasCycle) { this.hasCycle = hasCycle; }
    public boolean isDeadlockDetected() { return deadlockDetected; }
    public void setDeadlockDetected(boolean deadlockDetected) { this.deadlockDetected = deadlockDetected; }
    public List<TaskItem> getExecutionPipeline() { return executionPipeline; }
    public void setExecutionPipeline(List<TaskItem> executionPipeline) { this.executionPipeline = executionPipeline; }
    public List<String> getExecutionOrderKeys() { return executionOrderKeys; }
    public void setExecutionOrderKeys(List<String> executionOrderKeys) { this.executionOrderKeys = executionOrderKeys; }
    public List<String> getCycleNodes() { return cycleNodes; }
    public void setCycleNodes(List<String> cycleNodes) { this.cycleNodes = cycleNodes; }
    public List<String> getCycleEdgeDescriptions() { return cycleEdgeDescriptions; }
    public void setCycleEdgeDescriptions(List<String> cycleEdgeDescriptions) { this.cycleEdgeDescriptions = cycleEdgeDescriptions; }
    public Map<String, Integer> getInitialInDegrees() { return initialInDegrees; }
    public void setInitialInDegrees(Map<String, Integer> initialInDegrees) { this.initialInDegrees = initialInDegrees; }
    public List<TopologicalStep> getSteps() { return steps; }
    public void setSteps(List<TopologicalStep> steps) { this.steps = steps; }
    public String getDiagnosticMessage() { return diagnosticMessage; }
    public void setDiagnosticMessage(String diagnosticMessage) { this.diagnosticMessage = diagnosticMessage; }
    public long getExecutionTimeMicros() { return executionTimeMicros; }
    public void setExecutionTimeMicros(long executionTimeMicros) { this.executionTimeMicros = executionTimeMicros; }
}
