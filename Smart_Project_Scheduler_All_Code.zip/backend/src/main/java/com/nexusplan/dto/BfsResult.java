package com.nexusplan.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BfsResult {
    private Long startTaskId;
    private String startTaskKey;
    private List<String> traversalOrder = new ArrayList<>();
    private List<BfsStep> steps = new ArrayList<>();
    private Map<String, Integer> levelMap;
    private long executionTimeMicros;

    public static class BfsStep {
        private int stepNumber;
        private String currentNode;
        private List<String> queueState;
        private List<String> visitedNodes;
        private List<String> frontierNodes;
        private String actionMessage;

        public BfsStep() {}
        public BfsStep(int stepNumber, String currentNode, List<String> queueState,
                       List<String> visitedNodes, List<String> frontierNodes, String actionMessage) {
            this.stepNumber = stepNumber;
            this.currentNode = currentNode;
            this.queueState = queueState;
            this.visitedNodes = visitedNodes;
            this.frontierNodes = frontierNodes;
            this.actionMessage = actionMessage;
        }

        public int getStepNumber() { return stepNumber; }
        public void setStepNumber(int stepNumber) { this.stepNumber = stepNumber; }
        public String getCurrentNode() { return currentNode; }
        public void setCurrentNode(String currentNode) { this.currentNode = currentNode; }
        public List<String> getQueueState() { return queueState; }
        public void setQueueState(List<String> queueState) { this.queueState = queueState; }
        public List<String> getVisitedNodes() { return visitedNodes; }
        public void setVisitedNodes(List<String> visitedNodes) { this.visitedNodes = visitedNodes; }
        public List<String> getFrontierNodes() { return frontierNodes; }
        public void setFrontierNodes(List<String> frontierNodes) { this.frontierNodes = frontierNodes; }
        public String getActionMessage() { return actionMessage; }
        public void setActionMessage(String actionMessage) { this.actionMessage = actionMessage; }
    }

    public BfsResult() {}

    public Long getStartTaskId() { return startTaskId; }
    public void setStartTaskId(Long startTaskId) { this.startTaskId = startTaskId; }
    public String getStartTaskKey() { return startTaskKey; }
    public void setStartTaskKey(String startTaskKey) { this.startTaskKey = startTaskKey; }
    public List<String> getTraversalOrder() { return traversalOrder; }
    public void setTraversalOrder(List<String> traversalOrder) { this.traversalOrder = traversalOrder; }
    public List<BfsStep> getSteps() { return steps; }
    public void setSteps(List<BfsStep> steps) { this.steps = steps; }
    public Map<String, Integer> getLevelMap() { return levelMap; }
    public void setLevelMap(Map<String, Integer> levelMap) { this.levelMap = levelMap; }
    public long getExecutionTimeMicros() { return executionTimeMicros; }
    public void setExecutionTimeMicros(long executionTimeMicros) { this.executionTimeMicros = executionTimeMicros; }
}
