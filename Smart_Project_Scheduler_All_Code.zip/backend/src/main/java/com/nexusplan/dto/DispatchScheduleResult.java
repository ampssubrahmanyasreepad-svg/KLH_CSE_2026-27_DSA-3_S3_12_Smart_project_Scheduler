package com.nexusplan.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DispatchScheduleResult {
    private List<ScheduledTaskSlot> scheduleSlots = new ArrayList<>();
    private int totalPipelineDurationHours;
    private int activeWorkerCount;
    private Map<String, Integer> workerWorkloadsHours;
    private List<HeapEventLog> heapOperations = new ArrayList<>();
    private long executionTimeMicros;

    public static class ScheduledTaskSlot {
        private String taskKey;
        private String taskTitle;
        private String priority;
        private int durationHours;
        private String workerId;
        private int startHour;
        private int endHour;
        private double heuristicScore;
        private List<String> heapStateAtDispatch;

        public ScheduledTaskSlot() {}
        public ScheduledTaskSlot(String taskKey, String taskTitle, String priority, int durationHours,
                                 String workerId, int startHour, int endHour, double heuristicScore,
                                 List<String> heapStateAtDispatch) {
            this.taskKey = taskKey;
            this.taskTitle = taskTitle;
            this.priority = priority;
            this.durationHours = durationHours;
            this.workerId = workerId;
            this.startHour = startHour;
            this.endHour = endHour;
            this.heuristicScore = heuristicScore;
            this.heapStateAtDispatch = heapStateAtDispatch;
        }

        public String getTaskKey() { return taskKey; }
        public void setTaskKey(String taskKey) { this.taskKey = taskKey; }
        public String getTaskTitle() { return taskTitle; }
        public void setTaskTitle(String taskTitle) { this.taskTitle = taskTitle; }
        public String getPriority() { return priority; }
        public void setPriority(String priority) { this.priority = priority; }
        public int getDurationHours() { return durationHours; }
        public void setDurationHours(int durationHours) { this.durationHours = durationHours; }
        public String getWorkerId() { return workerId; }
        public void setWorkerId(String workerId) { this.workerId = workerId; }
        public int getStartHour() { return startHour; }
        public void setStartHour(int startHour) { this.startHour = startHour; }
        public int getEndHour() { return endHour; }
        public void setEndHour(int endHour) { this.endHour = endHour; }
        public double getHeuristicScore() { return heuristicScore; }
        public void setHeuristicScore(double heuristicScore) { this.heuristicScore = heuristicScore; }
        public List<String> getHeapStateAtDispatch() { return heapStateAtDispatch; }
        public void setHeapStateAtDispatch(List<String> heapStateAtDispatch) { this.heapStateAtDispatch = heapStateAtDispatch; }
    }

    public static class HeapEventLog {
        private String operation; // PUSH / HEAPIFY_UP / EXTRACT_MIN / HEAPIFY_DOWN
        private String taskKey;
        private String details;
        private List<String> heapArraySnapshot;

        public HeapEventLog() {}
        public HeapEventLog(String operation, String taskKey, String details, List<String> heapArraySnapshot) {
            this.operation = operation;
            this.taskKey = taskKey;
            this.details = details;
            this.heapArraySnapshot = heapArraySnapshot;
        }

        public String getOperation() { return operation; }
        public void setOperation(String operation) { this.operation = operation; }
        public String getTaskKey() { return taskKey; }
        public void setTaskKey(String taskKey) { this.taskKey = taskKey; }
        public String getDetails() { return details; }
        public void setDetails(String details) { this.details = details; }
        public List<String> getHeapArraySnapshot() { return heapArraySnapshot; }
        public void setHeapArraySnapshot(List<String> heapArraySnapshot) { this.heapArraySnapshot = heapArraySnapshot; }
    }

    public DispatchScheduleResult() {}

    public List<ScheduledTaskSlot> getScheduleSlots() { return scheduleSlots; }
    public void setScheduleSlots(List<ScheduledTaskSlot> scheduleSlots) { this.scheduleSlots = scheduleSlots; }
    public int getTotalPipelineDurationHours() { return totalPipelineDurationHours; }
    public void setTotalPipelineDurationHours(int totalPipelineDurationHours) { this.totalPipelineDurationHours = totalPipelineDurationHours; }
    public int getActiveWorkerCount() { return activeWorkerCount; }
    public void setActiveWorkerCount(int activeWorkerCount) { this.activeWorkerCount = activeWorkerCount; }
    public Map<String, Integer> getWorkerWorkloadsHours() { return workerWorkloadsHours; }
    public void setWorkerWorkloadsHours(Map<String, Integer> workerWorkloadsHours) { this.workerWorkloadsHours = workerWorkloadsHours; }
    public List<HeapEventLog> getHeapOperations() { return heapOperations; }
    public void setHeapOperations(List<HeapEventLog> heapOperations) { this.heapOperations = heapOperations; }
    public long getExecutionTimeMicros() { return executionTimeMicros; }
    public void setExecutionTimeMicros(long executionTimeMicros) { this.executionTimeMicros = executionTimeMicros; }
}
