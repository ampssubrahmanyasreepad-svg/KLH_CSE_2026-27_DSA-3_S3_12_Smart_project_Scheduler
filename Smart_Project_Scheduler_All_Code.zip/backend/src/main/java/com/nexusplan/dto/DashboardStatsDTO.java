package com.nexusplan.dto;

import java.util.Map;

public class DashboardStatsDTO {
    private int totalTasks;
    private int completedTasks;
    private int inProgressTasks;
    private int readyTasks;
    private int blockedTasks;
    private double completionRate;
    private int totalPapers;
    private int graphVertexCount;
    private int graphEdgeCount;
    private boolean isDagValid;
    private int criticalPathHours;
    private Map<String, Long> priorityDistribution;
    private Map<String, Long> statusDistribution;

    public DashboardStatsDTO() {}

    public int getTotalTasks() { return totalTasks; }
    public void setTotalTasks(int totalTasks) { this.totalTasks = totalTasks; }
    public int getCompletedTasks() { return completedTasks; }
    public void setCompletedTasks(int completedTasks) { this.completedTasks = completedTasks; }
    public int getInProgressTasks() { return inProgressTasks; }
    public void setInProgressTasks(int inProgressTasks) { this.inProgressTasks = inProgressTasks; }
    public int getReadyTasks() { return readyTasks; }
    public void setReadyTasks(int readyTasks) { this.readyTasks = readyTasks; }
    public int getBlockedTasks() { return blockedTasks; }
    public void setBlockedTasks(int blockedTasks) { this.blockedTasks = blockedTasks; }
    public double getCompletionRate() { return completionRate; }
    public void setCompletionRate(double completionRate) { this.completionRate = completionRate; }
    public int getTotalPapers() { return totalPapers; }
    public void setTotalPapers(int totalPapers) { this.totalPapers = totalPapers; }
    public int getGraphVertexCount() { return graphVertexCount; }
    public void setGraphVertexCount(int graphVertexCount) { this.graphVertexCount = graphVertexCount; }
    public int getGraphEdgeCount() { return graphEdgeCount; }
    public void setGraphEdgeCount(int graphEdgeCount) { this.graphEdgeCount = graphEdgeCount; }
    public boolean isDagValid() { return isDagValid; }
    public void setDagValid(boolean dagValid) { isDagValid = dagValid; }
    public int getCriticalPathHours() { return criticalPathHours; }
    public void setCriticalPathHours(int criticalPathHours) { this.criticalPathHours = criticalPathHours; }
    public Map<String, Long> getPriorityDistribution() { return priorityDistribution; }
    public void setPriorityDistribution(Map<String, Long> priorityDistribution) { this.priorityDistribution = priorityDistribution; }
    public Map<String, Long> getStatusDistribution() { return statusDistribution; }
    public void setStatusDistribution(Map<String, Long> statusDistribution) { this.statusDistribution = statusDistribution; }
}
